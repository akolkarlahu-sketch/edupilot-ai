# **App Name**: FitSutra AI

## Core Features:

- AI Wisdom Coach Tool: An intelligent fitness and nutrition chat interface that provides personalized Indian diet recommendations and motivational coaching based on user goals.
- Supabase Managed Core: Full backend implementation using Supabase for user authentication, workout logs, and tracking data storage.
- Dynamic Vitals Dashboard: A glassmorphic home screen featuring glass-styled cards for tracking daily streaks, calories, and a visual weight progress chart.
- Hydration Hub: Interactive water tracker with a circular progress indicator to help users reach their daily hydration targets.
- Custom Workout Curator: Segmented workout directory tailored for home or gym, including specialized routines for yoga and muscle gain.
- Diet Planning Suite: Daily meal logger optimized for Indian cuisine, tracking protein and calorie distribution across breakfast, lunch, and dinner.
- Onboarding Intelligence: Streamlined user data collection (age, activity level, fitness goals) used to personalize the AI coaching experience.

## Style Guidelines:

- Primary color: Emerald Vitality (#22C55E), a high-vibrancy green chosen for growth and health focus.
- Background color: Deep Obsidian (#090C0B), a desaturated dark hue providing a premium high-contrast base for dark-mode design.
- Accent: Lime Accent (#84CC16) to provide analogous variety for active highlights and secondary visual cues.
- Headline font: 'Space Grotesk' (sans-serif) for a modern, computerized, and precise technological feel. Body font: 'Inter' (sans-serif) for high legibility across density-rich tracking screens.
- Glassmorphism aesthetics with blurred card backgrounds, rounded corners (24px+), and generous white space to evoke a premium digital feel.
- Smooth slide transitions for page changes and elegant SVG progress animations for water and calorie charts.
- Ultra-thin, modern stroke icons that maintain visual clarity and professionalism against the dark theme.