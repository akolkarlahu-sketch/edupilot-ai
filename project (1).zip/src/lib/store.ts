
"use client"

import { create } from "zustand"
import { IndianDietPlanGeneratorOutput } from "@/ai/flows/indian-diet-plan-generator"
import { WorkoutPlanGeneratorOutput } from "@/ai/flows/workout-plan-generator"

export interface UserProfile {
  name: string
  age: number
  gender: string
  height: number
  weight: number
  targetWeight: number
  goal: string
  activityLevel: string
  dietPreference: string
  workoutPreference: string
  availableWorkoutTime: number
  createdAt?: string
  streak?: number
  lastActivityDate?: string
  totalWorkouts?: number
  badges?: string[]
}

interface AppState {
  user: UserProfile | null
  calories: number
  water: number
  dietPlan: IndianDietPlanGeneratorOutput | null
  workoutPlan: WorkoutPlanGeneratorOutput | null
  showCelebration: boolean
  celebrationType: 'streak' | 'workout' | 'hydration' | 'milestone' | null
  setUser: (user: UserProfile | null) => void
  setCalories: (amount: number) => void
  setWater: (amount: number) => void
  setDietPlan: (plan: IndianDietPlanGeneratorOutput | null) => void
  setWorkoutPlan: (plan: WorkoutPlanGeneratorOutput | null) => void
  triggerCelebration: (type: 'streak' | 'workout' | 'hydration' | 'milestone') => void
  hideCelebration: () => void
}

export const useStore = create<AppState>()((set) => ({
  user: null,
  calories: 0,
  water: 0,
  dietPlan: null,
  workoutPlan: null,
  showCelebration: false,
  celebrationType: null,
  setUser: (user) => set({ user }),
  setCalories: (calories) => set({ calories }),
  setWater: (water) => set({ water }),
  setDietPlan: (dietPlan) => set({ dietPlan }),
  setWorkoutPlan: (workoutPlan) => set({ workoutPlan }),
  triggerCelebration: (type) => set({ showCelebration: true, celebrationType: type }),
  hideCelebration: () => set({ showCelebration: false, celebrationType: null }),
}))
