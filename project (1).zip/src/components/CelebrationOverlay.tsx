
"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Sparkles, Trophy, Flame, Droplets, Star } from "lucide-react"
import { useStore } from "@/lib/store"
import { useEffect } from "react"

export function CelebrationOverlay() {
  const { showCelebration, celebrationType, hideCelebration } = useStore()

  useEffect(() => {
    if (showCelebration) {
      const timer = setTimeout(hideCelebration, 4000)
      return () => clearTimeout(timer)
    }
  }, [showCelebration, hideCelebration])

  const content = {
    streak: {
      icon: <Flame className="w-16 h-16 text-orange-500" />,
      title: "Streak Maintained!",
      desc: "Consistency is your greatest weapon.",
      color: "from-orange-500/20 to-red-500/20"
    },
    workout: {
      icon: <Trophy className="w-16 h-16 text-yellow-500" />,
      title: "Protocol Complete!",
      desc: "Elite performance achieved. Recalibrating stats.",
      color: "from-yellow-500/20 to-primary/20"
    },
    hydration: {
      icon: <Droplets className="w-16 h-16 text-blue-400" />,
      title: "Hydration Optimized",
      desc: "System efficiency at 100%. Protocol synchronized.",
      color: "from-blue-500/20 to-cyan-500/20"
    },
    milestone: {
      icon: <Star className="w-16 h-16 text-primary" />,
      title: "Milestone Reached!",
      desc: "You've unlocked a new tier of elite fitness.",
      color: "from-primary/20 to-accent/20"
    }
  }

  const activeContent = celebrationType ? content[celebrationType] : null

  return (
    <AnimatePresence>
      {showCelebration && activeContent && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md"
        >
          <motion.div
            initial={{ scale: 0.8, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.8, y: 20 }}
            className={`w-full max-w-sm rounded-[40px] border border-white/10 p-10 text-center relative overflow-hidden bg-gradient-to-br ${activeContent.color}`}
          >
            <div className="absolute inset-0 shimmer opacity-20" />
            
            <div className="relative z-10 space-y-6">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] }}
                transition={{ duration: 0.5, repeat: 3 }}
                className="w-24 h-24 rounded-[32px] glass mx-auto flex items-center justify-center shadow-2xl"
              >
                {activeContent.icon}
              </motion.div>
              
              <div className="space-y-2">
                <h2 className="text-3xl font-headline font-bold text-white tracking-tighter">{activeContent.title}</h2>
                <p className="text-muted-foreground text-sm font-medium">{activeContent.desc}</p>
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <button 
                  onClick={hideCelebration}
                  className="px-8 h-12 rounded-full emerald-gradient text-black font-bold uppercase tracking-widest text-xs shadow-xl"
                >
                  Continue Journey
                </button>
              </motion.div>
            </div>

            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-white/10 rounded-full blur-[80px]" />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
