'use client';

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { logError } from '@/firebase/analytics';
import { Button } from '@/components/ui/button';
import { AlertCircle, RefreshCcw } from 'lucide-react';
import { GlassCard } from './GlassCard';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    logError(error, `react_boundary: ${errorInfo.componentStack}`);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.href = '/dashboard';
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#050706] flex items-center justify-center p-6 text-center">
          <GlassCard className="max-w-md w-full p-10 border-destructive/20 space-y-6">
            <div className="w-20 h-20 rounded-[32px] bg-destructive/10 flex items-center justify-center mx-auto">
              <AlertCircle className="w-10 h-10 text-destructive" />
            </div>
            <div className="space-y-2">
              <h1 className="text-2xl font-headline font-bold text-white tracking-tight">System Interruption</h1>
              <p className="text-sm text-muted-foreground leading-relaxed">
                The neural link encountered a critical fault. Protocol integrity is being maintained.
              </p>
            </div>
            <Button 
              onClick={this.handleReset}
              className="w-full h-14 rounded-2xl bg-white/5 text-white hover:bg-white/10 font-bold"
            >
              <RefreshCcw className="mr-2 w-4 h-4" /> Reset Neural Link
            </Button>
          </GlassCard>
        </div>
      );
    }

    return this.props.children;
  }
}
