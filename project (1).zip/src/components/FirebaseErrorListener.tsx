'use client';

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';
import { useToast } from '@/hooks/use-toast';
import { logError } from '@/firebase/analytics';

export function FirebaseErrorListener() {
  const { toast } = useToast();

  useEffect(() => {
    // Global promise rejection handler (Crashlytics for unhandled logic errors)
    const handleRejection = (event: PromiseRejectionEvent) => {
      logError(event.reason, 'unhandled_rejection');
    };

    // Global script error handler
    const handleError = (event: ErrorEvent) => {
      logError(event.error, 'window_error');
    };

    window.addEventListener('unhandledrejection', handleRejection);
    window.addEventListener('error', handleError);

    const unsubscribe = errorEmitter.on('permission-error', (error: any) => {
      logError(error, 'firestore_permission');
      
      toast({
        variant: "destructive",
        title: "Security Violation",
        description: "Protocol access denied. Please re-authenticate.",
      });
      
      if (process.env.NODE_ENV === 'development') {
        console.error('Firestore Permission Denied:', error);
      }
    });

    return () => {
      window.removeEventListener('unhandledrejection', handleRejection);
      window.removeEventListener('error', handleError);
      unsubscribe();
    };
  }, [toast]);

  return null;
}
