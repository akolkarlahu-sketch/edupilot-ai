'use client';

import { useEffect } from 'react';
import { logEvent } from '@/firebase/analytics';

export function PWARegistration() {
  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker
          .register('/sw.js')
          .then((registration) => {
            console.log('SW registered:', registration.scope);
          })
          .catch((error) => {
            console.log('SW registration failed:', error);
          });
      });

      // Track PWA install event
      window.addEventListener('appinstalled', () => {
        logEvent('pwa_install_success');
      });
    }
  }, []);

  return null;
}
