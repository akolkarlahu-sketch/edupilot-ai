
"use client"

import { cn } from "@/lib/utils"
import { ReactNode } from "react"
import { motion } from "framer-motion"

interface GlassCardProps {
  children: ReactNode
  className?: string
  variant?: 'default' | 'dark' | 'emerald' | 'outline' | 'ghost'
  hover?: boolean
}

export function GlassCard({ children, className, variant = 'default', hover = false }: GlassCardProps) {
  const variants = {
    default: "bg-card/30 border-white/10 shadow-[0_4px_24px_rgba(0,0,0,0.5)]",
    dark: "bg-black/50 border-white/5 shadow-2xl",
    emerald: "bg-primary/5 border-primary/20",
    outline: "bg-transparent border-white/10",
    ghost: "bg-white/[0.02] border-white/5"
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={hover ? { y: -4, scale: 1.01 } : {}}
      whileTap={hover ? { scale: 0.98 } : {}}
      transition={{ type: "spring", stiffness: 400, damping: 25, mass: 0.5 }}
      className={cn(
        "backdrop-blur-2xl rounded-[32px] border p-6 relative overflow-hidden",
        variants[variant],
        className
      )}
    >
      <div className="absolute inset-0 shimmer opacity-20 pointer-events-none" aria-hidden="true" />
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  )
}
