
"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Dumbbell, MessageSquare, Utensils, User, BrainCircuit } from "lucide-react"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

const navItems = [
  { icon: Home, label: "Feed", href: "/dashboard" },
  { icon: Dumbbell, label: "Train", href: "/workouts" },
  { icon: BrainCircuit, label: "Labs", href: "/lab" },
  { icon: MessageSquare, label: "Coach", href: "/coach" },
  { icon: Utensils, label: "Fuel", href: "/diet" },
]

export function Navigation() {
  const pathname = usePathname()

  // Do not show navigation on the marketing landing page, onboarding, or auth
  if (pathname === "/" || pathname === "/onboarding" || pathname === "/auth") return null

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 flex justify-center pb-10 px-6 bg-gradient-to-t from-black via-black/90 to-transparent pointer-events-none">
      <div className="glass-dark w-full max-w-sm rounded-[40px] px-6 py-5 flex items-center justify-between shadow-[0_20px_50px_rgba(0,0,0,0.7)] border-white/10 pointer-events-auto">
        {navItems.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className="relative flex flex-col items-center gap-1 group"
            >
              <motion.div
                whileTap={{ scale: 0.8 }}
                className={cn(
                  "p-2.5 rounded-2xl transition-all duration-300 relative",
                  isActive 
                    ? "text-primary bg-primary/10 shadow-[0_0_20px_rgba(34,197,94,0.2)]" 
                    : "text-white/40 hover:text-white"
                )}
              >
                <item.icon 
                  className={cn("h-5 w-5 transition-transform duration-300", isActive && "scale-110")} 
                  strokeWidth={isActive ? 2.5 : 2} 
                />
                {isActive && (
                  <motion.div 
                    layoutId="nav-dot"
                    className="absolute -top-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-primary rounded-full"
                  />
                )}
              </motion.div>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
