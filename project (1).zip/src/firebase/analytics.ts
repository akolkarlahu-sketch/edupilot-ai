'use client';

import { logEvent as firebaseLogEvent } from 'firebase/analytics';
import { getAnalyticsInstance } from './index';

/**
 * Log a custom event to Firebase Analytics.
 */
export async function logEvent(eventName: string, eventParams?: { [key: string]: any }) {
  try {
    const analytics = await getAnalyticsInstance();
    if (analytics) {
      firebaseLogEvent(analytics, eventName, eventParams);
    }
  } catch (error) {
    console.warn('Analytics logging failed:', error);
  }
}

/**
 * Log an error to Firebase Analytics (Crashlytics Web Equivalent).
 */
export async function logError(error: Error | any, context?: string) {
  try {
    const analytics = await getAnalyticsInstance();
    if (analytics) {
      firebaseLogEvent(analytics, 'exception', {
        description: error.message || error.toString(),
        fatal: true,
        error_context: context || 'global',
        stack: error.stack || 'no_stack'
      });
    }
  } catch (e) {
    console.error('Error reporting failed:', e);
  }
}
