
"use client"

import { useState, useRef, useEffect, useMemo } from "react"
import { aiChatCoach } from "@/ai/flows/ai-chat-coach"
import { Navigation } from "@/components/Navigation"
import { Input } from "@/components/ui/input"
import { Send, Sparkles, Loader2, User, Bot, BrainCircuit, Zap } from "lucide-react"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"
import { useUser, useFirestore, useDoc, useMemoFirebase } from "@/firebase"
import { doc } from "firebase/firestore"
import { UserProfile } from "@/lib/store"
import { logEvent } from "@/firebase/analytics"

type Message = {
  role: "user" | "model"
  content: string
}

export default function CoachPage() {
  const { user: authUser } = useUser()
  const db = useFirestore()
  const userDocRef = useMemoFirebase(() => authUser ? doc(db, 'users', authUser.uid) : null, [db, authUser])
  const { data: profile } = useDoc<UserProfile>(userDocRef as any)

  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (profile && messages.length === 0) {
      setMessages([
        { 
          role: "model", 
          content: `Protocol active, ${profile.name.split(' ')[0]}. Neural analysis suggests focus on ${profile.goal} today. Based on your ${profile.dietPreference} preference, I've architected some high-performance options. How can I optimize your session?` 
        }
      ])
    } else if (!profile && messages.length === 0 && authUser) {
       setMessages([
        { 
          role: "model", 
          content: `Neural Link established. I am FitSutra AI, your elite performance coach. Transmit your profile metrics to begin protocol calibration.` 
        }
      ])
    }
  }, [profile, authUser, messages.length])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, isLoading])

  const suggestions = useMemo(() => {
    return [
      "Optimized Indian pre-workout?",
      "Recalibrate calorie load for muscle gain?",
      "15m Home mobility routine?",
      "Combat plateau in deadlift?"
    ]
  }, [])

  const handleSend = async (text: string = input) => {
    if (!text.trim() || isLoading) return

    const userMsg: Message = { role: "user", content: text }
    setMessages(prev => [...prev, userMsg])
    setInput("")
    setIsLoading(true)

    logEvent('ai_chat_message', {
      user_goal: profile?.goal,
      message_length: text.length
    })

    try {
      const response = await aiChatCoach({
        message: text,
        userProfile: profile ? {
          name: profile.name,
          age: profile.age,
          gender: profile.gender,
          height: profile.height,
          weight: profile.weight,
          goal: profile.goal,
          activityLevel: profile.activityLevel,
          dietPreference: profile.dietPreference
        } : undefined,
        history: messages
      })
      setMessages(prev => [...prev, { role: "model", content: response.response }])
    } catch (error) {
      setMessages(prev => [...prev, { role: "model", content: "Neural sync interrupted. Please re-transmit command." }])
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col h-screen bg-[#050706] relative">
      <header className="p-8 pt-16 glass border-b border-white/5 flex items-center justify-between sticky top-0 z-40 bg-[#050706]/80 backdrop-blur-2xl">
        <div className="flex items-center gap-5">
          <div className="w-12 h-12 rounded-[20px] emerald-gradient flex items-center justify-center shadow-[0_0_20px_rgba(34,197,94,0.4)] relative">
            <BrainCircuit className="w-6 h-6 text-black" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full border-2 border-background animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-headline font-bold text-white tracking-tight leading-none mb-1.5">FitSutra Coach</h1>
            <div className="flex items-center gap-2">
              <span className="text-[9px] text-primary font-bold uppercase tracking-[0.2em]">Neural Link Active</span>
            </div>
          </div>
        </div>
        <Zap className="w-5 h-5 text-white/20" />
      </header>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-8 space-y-8 scroll-smooth no-scrollbar pb-44"
      >
        <AnimatePresence initial={false} mode="popLayout">
          {messages.map((msg, i) => (
            <motion.div 
              key={`${msg.role}-${i}`} 
              initial={{ opacity: 0, y: 15, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              className={cn(
                "flex w-full gap-4",
                msg.role === "user" ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-1 shadow-lg",
                msg.role === "user" ? "bg-white/10" : "bg-primary/20 border border-primary/20"
              )}>
                {msg.role === "user" ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-primary" />}
              </div>
              <div className={cn(
                "max-w-[85%] rounded-[24px] p-5 text-[14px] leading-relaxed shadow-xl",
                msg.role === "user" 
                  ? "bg-primary text-black font-bold rounded-tr-none" 
                  : "bg-white/[0.03] border border-white/5 text-white/90 rounded-tl-none backdrop-blur-md"
              )}>
                {msg.content}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex justify-start gap-4"
          >
            <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center mt-1 border border-primary/10">
              <Bot className="w-5 h-5 text-primary" />
            </div>
            <div className="bg-white/[0.03] border border-white/5 rounded-[24px] p-5 flex gap-2 items-center">
              <motion.span animate={{ scale: [1, 1.4, 1], opacity: [0.5, 1, 0.5] }} transition={{ repeat: Infinity, duration: 1 }} className="w-2 h-2 rounded-full bg-primary" />
              <motion.span animate={{ scale: [1, 1.4, 1], opacity: [0.5, 1, 0.5] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-2 h-2 rounded-full bg-primary" />
              <motion.span animate={{ scale: [1, 1.4, 1], opacity: [0.5, 1, 0.5] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-2 h-2 rounded-full bg-primary" />
            </div>
          </motion.div>
        )}

        {messages.length <= 1 && !isLoading && (
          <div className="grid grid-cols-1 gap-3 pt-6">
            <p className="text-[10px] text-white/20 mb-1 px-1 uppercase font-bold tracking-[0.4em]">Neural Transmissions</p>
            {suggestions.map((s, i) => (
              <motion.button 
                key={i} 
                initial={{ opacity: 0, x: -15 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + i * 0.1, type: "spring" }}
                onClick={() => handleSend(s)}
                className="text-left bg-white/[0.02] border border-white/5 p-5 rounded-[24px] text-[12px] text-white/50 hover:border-primary/40 hover:text-white transition-all group flex items-center justify-between"
              >
                {s}
                <Sparkles className="w-4 h-4 text-primary opacity-0 group-hover:opacity-100 transition-all duration-300" />
              </motion.button>
            ))}
          </div>
        )}
      </div>

      <div className="fixed bottom-32 left-1/2 -translate-x-1/2 w-full max-w-md px-6 z-50">
        <div className="glass-dark border-white/10 rounded-[32px] p-2.5 relative flex items-center shadow-[0_20px_60px_rgba(0,0,0,0.8)]">
          <Input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Transmit command to FitSutra AI..."
            className="h-14 bg-transparent border-none text-white placeholder:text-white/20 focus-visible:ring-0 text-sm pl-6 pr-16"
          />
          <motion.button 
            whileTap={{ scale: 0.9 }}
            onClick={() => handleSend()}
            disabled={!input.trim() || isLoading}
            className="absolute right-3 w-12 h-12 rounded-[22px] emerald-gradient flex items-center justify-center shadow-xl disabled:opacity-30 btn-premium"
          >
            {isLoading ? <Loader2 className="w-5 h-5 text-black animate-spin" /> : <Send className="w-5 h-5 text-black" />}
          </motion.button>
        </div>
      </div>

      <Navigation />
    </div>
  )
}
