
"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { useUser } from "@/firebase"
import { 
  Sparkles, 
  BrainCircuit, 
  Zap, 
  Camera, 
  Dumbbell, 
  Trophy, 
  ChevronRight, 
  ArrowRight,
  Star,
  Quote,
  ShieldCheck,
  Smartphone,
  Mic2,
  TrendingUp
} from "lucide-react"
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { GlassCard } from "@/components/GlassCard"
import { Badge } from "@/components/ui/badge"

export default function LandingPage() {
  const router = useRouter()
  const { user, loading } = useUser()
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  })

  const opacity = useTransform(scrollYProgress, [0, 0.05], [1, 0])
  const scale = useTransform(scrollYProgress, [0, 0.05], [1, 0.9])

  return (
    <div ref={containerRef} className="min-h-screen bg-[#050706] text-white overflow-x-hidden selection:bg-primary selection:text-black">
      {/* Premium Gradient Backgrounds */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[20%] left-[-10%] w-[400px] h-[400px] bg-accent/5 rounded-full blur-[100px]" />
      </div>

      {/* Floating Navbar */}
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-[100] p-6 flex justify-center"
      >
        <div className="glass-dark border-white/10 rounded-full px-8 py-4 flex items-center justify-between w-full max-w-md shadow-2xl">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg emerald-gradient flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-black" />
            </div>
            <span className="font-headline font-bold text-lg tracking-tighter">FitSutra</span>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-xs font-bold uppercase tracking-widest text-primary hover:text-white"
            onClick={() => router.push(user ? "/dashboard" : "/auth")}
          >
            {loading ? "..." : user ? "The Hub" : "Login"}
          </Button>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative pt-44 pb-20 px-8 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="space-y-8 max-w-sm"
        >
          <Badge className="bg-primary/10 text-primary border-primary/20 rounded-full py-1.5 px-4 text-[10px] font-bold uppercase tracking-[0.3em]">
            Neural Evolution Active
          </Badge>
          <h1 className="text-6xl font-headline font-bold tracking-tighter leading-[0.9] text-white">
            The Neural Path to <span className="text-primary italic">Elite</span> Performance.
          </h1>
          <p className="text-muted-foreground text-sm leading-relaxed font-medium">
            FitSutra AI is a premium performance hub designed to architect your body using elite neural protocols and real-time biometric analysis.
          </p>
          <div className="flex flex-col gap-4 pt-4">
            <Button 
              onClick={() => router.push(user ? "/dashboard" : "/auth")}
              className="h-20 rounded-[32px] emerald-gradient text-black font-bold text-lg shadow-[0_20px_40px_rgba(34,197,94,0.3)] group btn-premium"
            >
              Initialize Hub 
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <p className="text-[10px] text-white/20 font-bold uppercase tracking-[0.4em]">Optimized for mobile-first users</p>
          </div>
        </motion.div>

        {/* Hero Illustration Preview */}
        <motion.div 
          style={{ opacity, scale }}
          className="mt-20 relative w-full aspect-[4/5] max-w-[320px] mx-auto"
        >
          <div className="absolute inset-0 bg-primary/20 rounded-[48px] blur-3xl animate-pulse" />
          <GlassCard className="h-full border-white/10 p-2 overflow-hidden bg-black/40" variant="dark">
            <img 
              src="https://picsum.photos/seed/fitsutrahero/600/800" 
              alt="Elite Athlete" 
              className="w-full h-full object-cover rounded-[28px] opacity-80 grayscale hover:grayscale-0 transition-all duration-700" 
              data-ai-hint="athlete workout"
            />
            <div className="absolute bottom-6 left-6 right-6 p-6 glass rounded-3xl border-primary/20">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl emerald-gradient flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-black" />
                </div>
                <div className="text-left">
                  <p className="text-[10px] text-primary font-bold uppercase tracking-widest">Growth Protocol</p>
                  <p className="text-white font-bold tracking-tight text-sm">+24% Efficiency</p>
                </div>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      </section>

      {/* Feature Section: AI Coach */}
      <section className="py-24 px-8 space-y-16">
        <div className="text-center space-y-4">
          <Badge variant="outline" className="border-primary/20 text-primary">Neural Intelligence</Badge>
          <h2 className="text-4xl font-headline font-bold tracking-tighter">Your Elite <span className="text-primary">Coach</span>.</h2>
        </div>

        <GlassCard className="p-8 border-primary/10 bg-primary/[0.02] space-y-8" hover>
          <div className="flex gap-6 items-start">
            <div className="w-14 h-14 rounded-3xl emerald-gradient flex items-center justify-center shadow-lg shrink-0">
              <BrainCircuit className="w-8 h-8 text-black" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-headline font-bold text-white">Neural Hub Link</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">A professional performance coach that remembers your goals, adapts to your fatigue, and architects daily winning protocols.</p>
            </div>
          </div>
          
          <div className="bg-white/5 rounded-[32px] p-6 space-y-4 border border-white/10">
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center"><Zap className="w-4 h-4 text-primary" /></div>
              <div className="bg-white/5 rounded-2xl rounded-tl-none p-3 text-[11px] text-white/70 max-w-[80%]">Protocol analysis suggest 300mg Caffeine + 15m Mobility before your Deadlift session.</div>
            </div>
            <div className="flex flex-row-reverse gap-3">
              <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center"><ArrowRight className="w-4 h-4 text-white" /></div>
              <div className="bg-primary text-black font-bold rounded-2xl rounded-tr-none p-3 text-[11px] max-w-[80%]">Understood. Neural link synchronized.</div>
            </div>
          </div>
        </GlassCard>
      </section>

      {/* Lab Features: Scanner & Transformation */}
      <section className="py-24 px-8 bg-black/40 space-y-12">
        <div className="grid grid-cols-1 gap-8">
          <GlassCard className="p-10 border-accent/20 bg-accent/[0.02] space-y-6 overflow-hidden" hover>
            <div className="flex justify-between items-start">
              <div className="w-16 h-16 rounded-[28px] bg-accent flex items-center justify-center shadow-2xl">
                <Camera className="w-8 h-8 text-black" />
              </div>
              <Badge className="bg-accent/20 text-accent border-accent/20">Active Labs</Badge>
            </div>
            <h3 className="text-3xl font-headline font-bold text-white tracking-tighter">Calorie Vision</h3>
            <p className="text-sm text-muted-foreground">Neural image recognition specifically tuned for Indian cuisine. Scan any dish for instant macro analysis.</p>
            <div className="pt-6 relative aspect-square max-w-[200px] mx-auto">
              <div className="absolute inset-0 border-2 border-accent/40 rounded-3xl animate-pulse" />
              <img 
                src="https://picsum.photos/seed/fitsutrascan/400/400" 
                className="w-full h-full object-cover rounded-3xl grayscale opacity-40" 
                alt="Scanner Preview" 
                data-ai-hint="indian food"
              />
              <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-accent shadow-[0_0_15px_rgba(34,197,94,1)] animate-[scan_3s_infinite]" />
            </div>
          </GlassCard>

          <GlassCard className="p-10 border-primary/20 bg-primary/[0.02] space-y-6" hover>
            <div className="w-16 h-16 rounded-[28px] emerald-gradient flex items-center justify-center shadow-2xl">
              <TrendingUp className="w-8 h-8 text-black" />
            </div>
            <h3 className="text-3xl font-headline font-bold text-white tracking-tighter">Synthesis Preview</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">Visualize your elite potential. Our Generative AI synthesizes your current physique with your goal data to show you the destination.</p>
            <div className="flex gap-2 pt-6">
              <div className="flex-1 h-32 bg-white/5 rounded-2xl border border-white/5 overflow-hidden grayscale">
                <img src="https://picsum.photos/seed/before/200/300" className="w-full h-full object-cover" data-ai-hint="before body" />
              </div>
              <div className="w-12 h-32 flex items-center justify-center"><ArrowRight className="text-primary" /></div>
              <div className="flex-1 h-32 bg-primary/20 rounded-2xl border border-primary/40 overflow-hidden shadow-[0_0_20px_rgba(34,197,94,0.3)]">
                <img src="https://picsum.photos/seed/after/200/300" className="w-full h-full object-cover" data-ai-hint="after body" />
              </div>
            </div>
          </GlassCard>
        </div>
      </section>

      {/* Voice Section */}
      <section className="py-24 px-8 text-center space-y-10">
        <div className="w-24 h-24 rounded-full emerald-gradient mx-auto flex items-center justify-center relative">
          <Mic2 className="w-12 h-12 text-black" />
          <motion.div 
            animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute inset-0 border-2 border-primary rounded-full"
          />
        </div>
        <h3 className="text-3xl font-headline font-bold tracking-tighter">Voice AI <span className="text-primary">Trainer</span></h3>
        <p className="text-sm text-muted-foreground max-w-xs mx-auto">Neural instructions whispered in your ear. Real-time form correction and elite motivation without touching your device.</p>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-8 space-y-12">
        <h3 className="text-2xl font-headline font-bold text-center tracking-tighter uppercase tracking-[0.3em] text-white/40">Elite Testimonials</h3>
        <div className="space-y-6">
          <TestimonialCard 
            quote="FitSutra AI replaced my human coach. The neural protocols for Indian diets are unmatched."
            name="Rahul M."
            role="Powerlifter"
          />
          <TestimonialCard 
            quote="The Calorie Scanner correctly identified my mom's home-cooked Poha. That's true magic."
            name="Sneha K."
            role="Marathoner"
          />
        </div>
      </section>

      {/* Footer / CTA */}
      <section className="py-32 px-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 blur-[120px] rounded-full" />
        <div className="relative z-10 space-y-10">
          <div className="w-20 h-20 rounded-[32px] emerald-gradient mx-auto flex items-center justify-center shadow-2xl mb-12">
            <Sparkles className="w-10 h-10 text-black" />
          </div>
          <h2 className="text-5xl font-headline font-bold tracking-tighter leading-tight">Ready to <span className="text-primary">Evolve</span>?</h2>
          <p className="text-muted-foreground text-sm max-w-[280px] mx-auto">Join the next generation of performance athletes. Install the PWA for the full elite experience.</p>
          <Button 
            onClick={() => router.push("/auth")}
            className="h-20 w-full max-w-sm rounded-[32px] emerald-gradient text-black font-bold text-lg shadow-2xl btn-premium"
          >
            Get Started Now
          </Button>
          
          <div className="flex items-center justify-center gap-8 pt-12 text-white/20">
            <ShieldCheck className="w-6 h-6" />
            <Smartphone className="w-6 h-6" />
            <Trophy className="w-6 h-6" />
          </div>
          
          <p className="text-[10px] text-white/20 uppercase tracking-[0.5em] pt-12">© 2024 FitSutra AI • Neural Performance Lab</p>
        </div>
      </section>

      <style jsx global>{`
        @keyframes scan {
          0% { top: 0%; }
          100% { top: 100%; }
        }
      `}</style>
    </div>
  )
}

function TestimonialCard({ quote, name, role }: { quote: string, name: string, role: string }) {
  return (
    <GlassCard className="p-8 space-y-6 border-white/5 bg-white/[0.02]" hover>
      <Quote className="w-8 h-8 text-primary/40" />
      <p className="text-sm italic text-white/80 leading-relaxed">"{quote}"</p>
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-full bg-white/5" />
        <div>
          <p className="text-xs font-bold text-white">{name}</p>
          <p className="text-[10px] text-primary uppercase font-bold tracking-widest">{role}</p>
        </div>
      </div>
    </GlassCard>
  )
}
