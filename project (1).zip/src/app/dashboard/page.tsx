
"use client"

import { useState, useMemo, useEffect } from "react"
import { GlassCard } from "@/components/GlassCard"
import { Navigation } from "@/components/Navigation"
import { CelebrationOverlay } from "@/components/CelebrationOverlay"
import { useFirestore, useDoc, useCollection, useUser, useMemoFirebase } from "@/firebase"
import { doc, updateDoc, collection, query, orderBy, limit, addDoc } from "firebase/firestore"
import { 
  Flame, 
  Droplets, 
  Zap, 
  TrendingUp, 
  Weight,
  Plus,
  ArrowUpRight,
  Target,
  Activity,
  Timer,
  Users,
  Trophy
} from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { 
  ResponsiveContainer, 
  XAxis, 
  YAxis, 
  Tooltip,
  AreaChart,
  Area
} from "recharts"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import { UserProfile, useStore } from "@/lib/store"
import { logEvent } from "@/firebase/analytics"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

const DEMO_LEADERBOARD = [
  { name: "Arjun S.", streak: 42, id: "demo1" },
  { name: "Priya K.", streak: 38, id: "demo2" },
  { name: "Vikram R.", streak: 31, id: "demo3" },
  { name: "Ananya M.", streak: 27, id: "demo4" },
  { name: "Karan P.", streak: 24, id: "demo5" },
]

const DEMO_WEIGHT_LOGS = [
  { date: 'Mon', weight: 82.5 },
  { date: 'Tue', weight: 82.1 },
  { date: 'Wed', weight: 81.8 },
  { date: 'Thu', weight: 81.9 },
  { date: 'Fri', weight: 81.4 },
  { date: 'Sat', weight: 81.2 },
  { date: 'Sun', weight: 80.8 },
]

export default function Dashboard() {
  const { user: authUser, loading: authLoading } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const triggerCelebration = useStore(state => state.triggerCelebration)
  const [newWeight, setNewWeight] = useState("")
  const [isWeightDialogOpen, setIsWeightDialogOpen] = useState(false)
  const [today, setToday] = useState<string>("")

  useEffect(() => {
    setToday(new Date().toISOString().split('T')[0])
  }, [])

  const userDocRef = useMemoFirebase(() => 
    authUser ? doc(db, 'users', authUser.uid) : null, 
  [db, authUser])
  const { data: profile, loading: profileLoading } = useDoc<UserProfile>(userDocRef as any)

  const weightQuery = useMemoFirebase(() => 
    authUser ? query(collection(db, 'users', authUser.uid, 'progress_logs'), orderBy('date', 'desc'), limit(10)) : null,
  [db, authUser])
  const { data: weightLogs } = useCollection<any>(weightQuery)

  const waterQuery = useMemoFirebase(() => 
    authUser ? query(collection(db, 'users', authUser.uid, 'water_logs')) : null,
  [db, authUser])
  const { data: waterLogs } = useCollection<any>(waterQuery)

  const leaderboardQuery = useMemoFirebase(() => 
    query(collection(db, 'users'), orderBy('streak', 'desc'), limit(5)),
  [db])
  const { data: topUsers } = useCollection<any>(leaderboardQuery)

  useEffect(() => {
    if (authUser) {
      logEvent('dashboard_visit', { user_id: authUser.uid })
    }
  }, [authUser])

  const dailyWater = useMemo(() => {
    if (!today) return 0
    return waterLogs?.filter(log => log.date === today).reduce((sum, log) => sum + (log.amountMl || 0), 0) || 0
  }, [waterLogs, today])

  const chartData = useMemo(() => {
    if (!weightLogs || weightLogs.length === 0) return DEMO_WEIGHT_LOGS
    return [...weightLogs].reverse().map(log => ({
      date: new Date(log.date).toLocaleDateString('en-US', { weekday: 'short' }),
      weight: log.weight
    }))
  }, [weightLogs])

  const weightProgress = useMemo(() => {
    if (!profile?.weight || !profile?.targetWeight) return 0
    const current = profile.weight
    const target = profile.targetWeight
    const initial = current + 5 
    const totalToLose = initial - target
    const remaining = current - target
    if (totalToLose <= 0) return 100
    return Math.max(0, Math.min(100, ((totalToLose - remaining) / totalToLose) * 100))
  }, [profile])

  const leaderboardData = useMemo(() => {
    return (topUsers && topUsers.length > 0) ? topUsers : DEMO_LEADERBOARD
  }, [topUsers])

  const handleWeightSubmit = () => {
    const w = parseFloat(newWeight)
    if (!isNaN(w) && authUser && today) {
      const userRef = doc(db, 'users', authUser.uid)
      const logRef = collection(db, 'users', authUser.uid, 'progress_logs')
      
      addDoc(logRef, { userId: authUser.uid, weight: w, date: today })
        .catch(async () => {
          errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: `users/${authUser.uid}/progress_logs`,
            operation: 'create',
            requestResourceData: { weight: w, date: today }
          }));
        });

      updateDoc(userRef, { weight: w })
        .catch(async () => {
          errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: userRef.path,
            operation: 'update',
            requestResourceData: { weight: w }
          }));
        });

      logEvent('weight_log_update', { weight: w })
      setIsWeightDialogOpen(false)
      toast({ title: "Protocol Sync", description: `Updated body mass to ${w}kg.` })
    }
  }

  const handleAddWater = () => {
    if (authUser && today) {
      const waterRef = collection(db, 'users', authUser.uid, 'water_logs')
      const payload = { userId: authUser.uid, amountMl: 250, date: today }
      
      addDoc(waterRef, payload)
        .catch(async () => {
          errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: `users/${authUser.uid}/water_logs`,
            operation: 'create',
            requestResourceData: payload
          }));
        });

      logEvent('water_intake_add', { amount: 250 })
      if (dailyWater + 250 >= 3000 && dailyWater < 3000) {
        triggerCelebration('hydration')
        logEvent('hydration_goal_reached')
      }
    }
  }

  if (authLoading || profileLoading || !today) return <DashboardSkeleton />

  return (
    <div className="min-h-screen pb-40 bg-[#050706] relative">
      <CelebrationOverlay />
      
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-8 pt-16 flex items-center justify-between sticky top-0 z-40 bg-[#050706]/60 backdrop-blur-xl"
      >
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-headline font-bold text-white tracking-tighter">Elite <span className="text-primary">Hub</span></h1>
            <div className="flex items-center gap-1.5 bg-orange-500/10 px-2.5 py-1 rounded-full border border-orange-500/20">
              <Flame className="w-3.5 h-3.5 text-orange-500 fill-orange-500" />
              <span className="text-[10px] font-bold text-orange-500 uppercase tracking-widest">{profile?.streak || 1}d</span>
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-[0.4em]">Neural Link Synchronized</p>
        </div>
        <motion.div 
          whileTap={{ scale: 0.9 }}
          className="w-14 h-14 rounded-[24px] glass p-0.5 overflow-hidden border-primary/20 shadow-[0_0_20px_rgba(34,197,94,0.2)]"
        >
          <img 
            src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${authUser?.uid || "user"}`} 
            alt="Avatar" 
            className="w-full h-full object-cover rounded-[22px]" 
          />
        </motion.div>
      </motion.header>

      <div className="px-6 space-y-8 mt-4">
        <div className="grid grid-cols-2 gap-4">
          <GlassCard className="p-6 border-primary/10 bg-primary/[0.03]" hover>
            <div className="flex justify-between items-start mb-6">
              <div className="w-10 h-10 rounded-2xl glass flex items-center justify-center">
                <Target className="w-5 h-5 text-primary" />
              </div>
              <Activity className="w-4 h-4 text-white/20" />
            </div>
            <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1">Target</p>
            <div className="flex items-baseline gap-1.5">
              <span className="text-4xl font-headline font-bold text-white tracking-tighter">{profile?.targetWeight || "70"}</span>
              <span className="text-xs text-muted-foreground font-bold">kg</span>
            </div>
            <Progress value={weightProgress || 45} className="h-1.5 mt-4 bg-white/5" />
          </GlassCard>

          <GlassCard className="p-6 border-accent/10 bg-accent/[0.03]" hover>
            <div className="flex justify-between items-start mb-6">
              <div className="w-10 h-10 rounded-2xl glass flex items-center justify-center">
                <Zap className="w-5 h-5 text-accent" />
              </div>
              <Timer className="w-4 h-4 text-white/20" />
            </div>
            <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1">Active Burn</p>
            <div className="flex items-baseline gap-1.5">
              <span className="text-4xl font-headline font-bold text-white tracking-tighter">840</span>
              <span className="text-xs text-muted-foreground font-bold">kcal</span>
            </div>
            <div className="flex gap-1.5 mt-4">
              {[1, 1, 1, 0, 0, 0, 0].map((v, i) => (
                <div key={i} className={`h-1.5 flex-1 rounded-full ${v ? 'bg-accent' : 'bg-white/5'}`} />
              ))}
            </div>
          </GlassCard>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-white flex items-center gap-2 uppercase tracking-[0.3em]">
              <Users className="w-4 h-4 text-primary" /> Elite Leaderboard
            </h3>
          </div>
          <GlassCard className="p-4 bg-black/40 border-white/5">
            <div className="space-y-4">
              {leaderboardData.map((user, i) => (
                <div key={user.id || i} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-bold text-primary w-4">{i + 1}</span>
                    <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.id || user.name}`} className="w-8 h-8 rounded-lg" alt={user.name} />
                    <span className="text-sm font-bold text-white/80">{user.name}</span>
                    {i === 0 && <Trophy className="w-3 h-3 text-yellow-500" />}
                  </div>
                  <div className="flex items-center gap-1">
                    <Flame className="w-3 h-3 text-orange-500" />
                    <span className="text-xs font-bold text-white/60">{user.streak}d</span>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>

        <div className="space-y-5">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-white flex items-center gap-2 uppercase tracking-[0.3em]">
              <TrendingUp className="w-4 h-4 text-primary" /> Transformation
            </h3>
          </div>
          <GlassCard className="p-2 pt-8 overflow-hidden bg-black/40 border-white/5">
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22C55E" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#22C55E" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#666', fontWeight: 700 }} />
                  <YAxis domain={['dataMin - 1', 'dataMax + 1']} hide />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(5, 7, 6, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', fontSize: '11px' }}
                    itemStyle={{ color: '#22C55E', fontWeight: 'bold' }}
                  />
                  <Area type="monotone" dataKey="weight" stroke="#22C55E" strokeWidth={4} fillOpacity={1} fill="url(#chartGradient)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </GlassCard>
        </div>

        <div className="space-y-4">
          <GlassCard className="flex items-center justify-between py-5 border-blue-500/10 bg-blue-500/[0.02]" hover>
            <div className="flex items-center gap-5">
              <div className="w-14 h-14 rounded-3xl glass-dark flex items-center justify-center border-blue-400/20 shadow-inner">
                <Droplets className="w-6 h-6 text-blue-400" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-white text-sm tracking-tight">System Hydration</h4>
                <div className="flex items-center gap-2">
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">{dailyWater} / 3000 ml</p>
                  <span className="text-[10px] text-blue-400 font-bold">{Math.round((dailyWater/3000)*100)}%</span>
                </div>
                <Progress value={(dailyWater / 3000) * 100} className="h-1.5 w-32 bg-white/5 mt-2" />
              </div>
            </div>
            <Button size="icon" className="h-14 w-14 rounded-3xl glass border-white/5 btn-premium" onClick={handleAddWater}>
              <Plus className="w-6 h-6 text-white" />
            </Button>
          </GlassCard>

          <Dialog open={isWeightDialogOpen} onOpenChange={setIsWeightDialogOpen}>
            <DialogTrigger asChild>
              <button className="w-full text-left">
                <GlassCard className="flex items-center justify-between py-5 border-accent/10 bg-accent/[0.02]" hover>
                  <div className="flex items-center gap-5">
                    <div className="w-14 h-14 rounded-3xl glass-dark flex items-center justify-center border-accent/20">
                      <Weight className="w-6 h-6 text-accent" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-bold text-white text-sm tracking-tight">Update Body Mass</h4>
                      <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Current: {profile?.weight || "80.8"} kg</p>
                    </div>
                  </div>
                  <div className="w-12 h-12 rounded-2xl glass flex items-center justify-center">
                    <ArrowUpRight className="w-5 h-5 text-muted-foreground" />
                  </div>
                </GlassCard>
              </button>
            </DialogTrigger>
            <DialogContent className="glass border-white/10 bg-black/95 text-white rounded-[48px] p-12 max-w-[360px] mx-auto shadow-2xl">
              <DialogHeader><DialogTitle className="font-headline font-bold text-3xl text-center tracking-tighter mb-4">Body Mass Sync</DialogTitle></DialogHeader>
              <div className="space-y-10 pt-6">
                <div className="relative">
                  <Input 
                    type="number"
                    value={newWeight}
                    onChange={(e) => setNewWeight(e.target.value)}
                    className="h-28 bg-white/5 border-white/10 rounded-[32px] text-5xl font-headline font-bold text-center"
                    placeholder={profile?.weight?.toString() || "0.0"}
                  />
                  <span className="absolute right-10 top-1/2 -translate-y-1/2 text-white/20 font-bold text-2xl">kg</span>
                </div>
                <Button onClick={handleWeightSubmit} className="w-full h-20 rounded-[32px] emerald-gradient text-black font-bold text-lg shadow-2xl btn-premium uppercase">Synchronize</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      <Navigation />
    </div>
  )
}

function DashboardSkeleton() {
  return (
    <div className="min-h-screen p-8 pt-20 space-y-10 bg-[#050706]">
      <div className="flex justify-between items-center"><Skeleton className="h-10 w-56 bg-white/5 rounded-2xl" /><Skeleton className="w-14 h-14 rounded-[24px] bg-white/5" /></div>
      <div className="grid grid-cols-2 gap-4"><Skeleton className="h-44 rounded-[32px] bg-white/5" /><Skeleton className="h-44 rounded-[32px] bg-white/5" /></div>
      <Skeleton className="h-28 rounded-[32px] bg-white/5" /><Skeleton className="h-64 rounded-[32px] bg-white/5" />
    </div>
  )
}
