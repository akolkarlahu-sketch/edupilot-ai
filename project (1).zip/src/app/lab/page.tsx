
"use client"

import { useState, useRef } from "react"
import { GlassCard } from "@/components/GlassCard"
import { Navigation } from "@/components/Navigation"
import { Button } from "@/components/ui/button"
import { Camera, Sparkles, Loader2, Zap, BrainCircuit, ScanLine, Image as ImageIcon } from "lucide-react"
import { analyzeFood } from "@/ai/flows/food-analysis-flow"
import { previewTransformation } from "@/ai/flows/transformation-flow"
import { useUser, useFirestore } from "@/firebase"
import { collection, addDoc } from "firebase/firestore"
import { useToast } from "@/hooks/use-toast"
import { motion, AnimatePresence } from "framer-motion"
import { logEvent } from "@/firebase/analytics"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

export default function LabPage() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const [isScanning, setIsScanning] = useState(false)
  const [isSynthesizing, setIsSynthesizing] = useState(false)
  const [scanResult, setScanResult] = useState<any>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const transformInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, mode: 'scan' | 'transform') => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onloadend = async () => {
      const base64 = reader.result as string
      if (mode === 'scan') {
        setIsScanning(true)
        logEvent('food_scan_initiated')
        try {
          const result = await analyzeFood({ photoDataUri: base64 })
          setScanResult(result)
          if (user) {
            const payload = {
              ...result,
              userId: user.uid,
              timestamp: new Date().toISOString()
            }
            addDoc(collection(db, 'users', user.uid, 'food_logs'), payload)
              .catch(async () => {
                errorEmitter.emit('permission-error', new FirestorePermissionError({
                  path: `users/${user.uid}/food_logs`,
                  operation: 'create',
                  requestResourceData: payload
                }));
              });
          }
          logEvent('food_scan_success', { dish: result.dishName, calories: result.calories })
          toast({ title: "Neural Scan Complete", description: `Identified: ${result.dishName}` })
        } catch (err) {
          toast({ variant: "destructive", title: "Scan Failed", description: "Cloud link unstable." })
        } finally {
          setIsScanning(false)
        }
      } else {
        setIsSynthesizing(true)
        logEvent('transformation_preview_initiated')
        try {
          const result = await previewTransformation({ 
            photoDataUri: base64, 
            goal: "Elite Muscular Physique" 
          })
          setPreviewUrl(result.mediaUrl)
          logEvent('transformation_preview_success')
          toast({ title: "Synthesis Complete", description: "Visualized potential achieved." })
        } catch (err) {
          toast({ variant: "destructive", title: "Synthesis Failed", description: "Neural synthesis interrupted." })
        } finally {
          setIsSynthesizing(false)
        }
      }
    }
    reader.readAsDataURL(file)
  }

  return (
    <div className="min-h-screen pb-40 bg-[#050706] relative">
      <header className="p-8 pt-16 flex items-center justify-between sticky top-0 z-40 bg-[#050706]/80 backdrop-blur-2xl border-b border-white/5">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl emerald-gradient flex items-center justify-center shadow-lg">
            <BrainCircuit className="w-6 h-6 text-black" />
          </div>
          <div>
            <h1 className="text-xl font-headline font-bold text-white tracking-tight">Elite Labs</h1>
            <span className="text-[9px] text-primary font-bold uppercase tracking-[0.2em]">Beta Neural Features</span>
          </div>
        </div>
      </header>

      <div className="px-6 space-y-8 mt-8">
        <GlassCard className="p-8 space-y-6 overflow-hidden border-primary/20 bg-primary/[0.03]" hover>
          <div className="flex justify-between items-start">
            <div className="space-y-2">
              <h2 className="text-2xl font-headline font-bold text-white tracking-tight">Calorie Vision</h2>
              <p className="text-sm text-muted-foreground">Neural scanning for instant macro analysis.</p>
            </div>
            <ScanLine className="w-6 h-6 text-primary animate-pulse" />
          </div>

          {scanResult && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white/5 rounded-2xl p-4 border border-white/10 space-y-3">
              <h3 className="font-bold text-white text-lg">{scanResult.dishName}</h3>
              <div className="grid grid-cols-4 gap-2">
                <MacroItem label="CAL" value={scanResult.calories} />
                <MacroItem label="PRO" value={scanResult.protein} />
                <MacroItem label="CAR" value={scanResult.carbs} />
                <MacroItem label="FAT" value={scanResult.fats} />
              </div>
            </motion.div>
          )}

          <Button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isScanning}
            className="w-full h-16 rounded-[24px] emerald-gradient text-black font-bold uppercase tracking-widest text-xs btn-premium"
          >
            {isScanning ? <Loader2 className="w-6 h-6 animate-spin" /> : <Camera className="w-5 h-5 mr-2" />}
            {isScanning ? "Processing Scan..." : "Capture Food Hub"}
          </Button>
          <input type="file" accept="image/*" ref={fileInputRef} className="hidden" onChange={(e) => handleFileChange(e, 'scan')} />
        </GlassCard>

        <GlassCard className="p-8 space-y-6 overflow-hidden border-accent/20 bg-accent/[0.03]" hover>
          <div className="flex justify-between items-start">
            <div className="space-y-2">
              <h2 className="text-2xl font-headline font-bold text-white tracking-tight">Transformation AI</h2>
              <p className="text-sm text-muted-foreground">Visualize your elite potential results.</p>
            </div>
            <Zap className="w-6 h-6 text-accent" />
          </div>

          <AnimatePresence>
            {previewUrl && (
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="aspect-square rounded-[32px] overflow-hidden border-4 border-accent/30 shadow-2xl">
                <img src={previewUrl} alt="Synthesis" className="w-full h-full object-cover" />
              </motion.div>
            )}
          </AnimatePresence>

          <Button 
            onClick={() => transformInputRef.current?.click()}
            disabled={isSynthesizing}
            className="w-full h-16 rounded-[24px] bg-accent text-black font-bold uppercase tracking-widest text-xs btn-premium shadow-accent/20"
          >
            {isSynthesizing ? <Loader2 className="w-6 h-6 animate-spin" /> : <ImageIcon className="w-5 h-5 mr-2" />}
            {isSynthesizing ? "Synthesizing..." : "Preview Transformation"}
          </Button>
          <input type="file" accept="image/*" ref={transformInputRef} className="hidden" onChange={(e) => handleFileChange(e, 'transform')} />
        </GlassCard>

        <GlassCard className="p-8 border-white/5 bg-white/[0.02]" hover>
          <div className="flex gap-6 items-center">
            <div className="w-14 h-14 rounded-2xl glass flex items-center justify-center shrink-0">
              <Sparkles className="w-7 h-7 text-primary" />
            </div>
            <div className="space-y-1">
              <h3 className="text-xs font-bold text-white uppercase tracking-widest">Premium Features</h3>
              <p className="text-[12px] text-muted-foreground leading-relaxed">
                Unlock <strong>Voice AI Trainer</strong> and <strong>Smartwatch Sync</strong> in the prochain cycle.
              </p>
            </div>
          </div>
        </GlassCard>
      </div>

      <Navigation />
    </div>
  )
}

function MacroItem({ label, value }: { label: string, value: number }) {
  return (
    <div className="text-center">
      <p className="text-[9px] font-bold text-muted-foreground uppercase">{label}</p>
      <p className="text-sm font-headline font-bold text-white">{value}</p>
    </div>
  )
}
