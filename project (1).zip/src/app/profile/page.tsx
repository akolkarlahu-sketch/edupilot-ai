"use client"

import { GlassCard } from "@/components/GlassCard"
import { Navigation } from "@/components/Navigation"
import { useStore } from "@/lib/store"
import { 
  Settings, 
  CreditCard, 
  Bell, 
  Shield, 
  HelpCircle, 
  LogOut, 
  ChevronRight,
  User,
  Star
} from "lucide-react"
import { useRouter } from "next/navigation"

export default function ProfilePage() {
  const router = useRouter()
  const { user } = useStore()

  const handleLogout = () => {
    router.push("/")
  }

  const menuItems = [
    { icon: User, label: "Edit Profile", color: "text-blue-400" },
    { icon: Bell, label: "Notifications", color: "text-orange-400" },
    { icon: Shield, label: "Privacy & Security", color: "text-primary" },
    { icon: HelpCircle, label: "Help Center", color: "text-purple-400" },
  ]

  return (
    <div className="min-h-screen pb-32">
      <header className="p-8 pt-12 text-center space-y-4">
        <div className="relative inline-block">
          <div className="w-28 h-28 rounded-full emerald-gradient p-1">
            <div className="w-full h-full rounded-full bg-background flex items-center justify-center overflow-hidden">
              <img 
                src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.name || "user"}`} 
                alt="Avatar" 
                className="w-full h-full" 
              />
            </div>
          </div>
          <div className="absolute bottom-1 right-1 w-8 h-8 rounded-full emerald-gradient border-4 border-background flex items-center justify-center">
            <Star className="w-4 h-4 text-black" fill="currentColor" />
          </div>
        </div>
        
        <div className="space-y-1">
          <h1 className="text-2xl font-headline font-bold text-white">{user?.name || "Fitness Enthusiast"}</h1>
          <p className="text-muted-foreground">{user?.goal?.replace('_', ' ') || "Weight Loss"} Journey</p>
        </div>

        <div className="flex justify-center gap-8 mt-4">
          <div className="text-center">
            <p className="text-xl font-headline font-bold text-white">{user?.height || 175}</p>
            <p className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Height</p>
          </div>
          <div className="text-center border-x border-white/5 px-8">
            <p className="text-xl font-headline font-bold text-white">{user?.weight || 75}</p>
            <p className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Weight</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-headline font-bold text-white">{user?.age || 25}</p>
            <p className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Age</p>
          </div>
        </div>
      </header>

      <div className="px-6 space-y-6">
        <GlassCard className="bg-gradient-to-br from-yellow-500/20 to-orange-500/10 border-yellow-500/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl glass-dark flex items-center justify-center">
                <Star className="w-6 h-6 text-yellow-500" fill="currentColor" />
              </div>
              <div>
                <h3 className="font-bold text-white">FitSutra Pro</h3>
                <p className="text-xs text-muted-foreground">Unlock personalized AI workouts</p>
              </div>
            </div>
            <button className="bg-yellow-500 text-black text-xs font-bold px-4 py-2 rounded-full">Upgrade</button>
          </div>
        </GlassCard>

        <div className="space-y-3">
          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-[0.2em] ml-2">General Settings</h3>
          {menuItems.map((item, i) => (
            <GlassCard key={i} className="flex items-center justify-between py-4 group cursor-pointer hover:border-primary/40 transition-all">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl glass-dark flex items-center justify-center ${item.color}`}>
                  <item.icon className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium text-white/90">{item.label}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-white transition-colors" />
            </GlassCard>
          ))}
        </div>

        <button 
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 p-4 rounded-3xl glass border-red-500/20 text-red-400 font-bold hover:bg-red-500/10 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          Logout
        </button>

        <p className="text-center text-[10px] text-muted-foreground opacity-50">
          FitSutra AI v2.4.0 • Built with precision
        </p>
      </div>

      <Navigation />
    </div>
  )
}