
"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useFirestore, useUser } from "@/firebase"
import { doc, setDoc } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select"
import { ChevronRight, ChevronLeft, Sparkles, Target, Zap, Clock, Dumbbell } from "lucide-react"
import { GlassCard } from "@/components/GlassCard"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { logEvent } from "@/firebase/analytics"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

export default function Onboarding() {
  const router = useRouter()
  const { user: authUser } = useUser()
  const db = useFirestore()
  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    height: "",
    weight: "",
    targetWeight: "",
    goal: "",
    activityLevel: "",
    dietPreference: "",
    workoutPreference: "",
    availableWorkoutTime: "45"
  })

  const next = () => setStep(prev => prev + 1)
  const prev = () => setStep(prev => prev - 1)

  const handleFinish = async () => {
    if (!authUser) return
    setLoading(true)
    
    const profile = {
      name: formData.name || "User",
      age: parseInt(formData.age) || 25,
      gender: formData.gender || "male",
      height: parseInt(formData.height) || 175,
      weight: parseInt(formData.weight) || 75,
      targetWeight: parseInt(formData.targetWeight) || 70,
      goal: formData.goal || "fitness",
      activityLevel: formData.activityLevel || "moderately active",
      dietPreference: formData.dietPreference || "vegetarian",
      workoutPreference: formData.workoutPreference || "home",
      availableWorkoutTime: parseInt(formData.availableWorkoutTime) || 45,
      createdAt: new Date().toISOString(),
      streak: 1,
      totalWorkouts: 0,
      points: 0
    }

    const userRef = doc(db, 'users', authUser.uid)
    
    setDoc(userRef, profile)
      .then(() => {
        logEvent('onboarding_complete', {
          goal: profile.goal,
          diet: profile.dietPreference,
          gender: profile.gender
        })
        router.push("/dashboard")
      })
      .catch(async () => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: userRef.path,
          operation: 'create',
          requestResourceData: profile
        }));
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const steps = [
    {
      title: "The Identity",
      desc: "Who is the athlete behind the profile?",
      icon: Sparkles,
      content: (
        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-white/80">Full Name</Label>
            <Input 
              placeholder="e.g. Arjun Singh" 
              className="h-14 bg-white/5 border-white/10 text-white rounded-2xl" 
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white/80">Age</Label>
              <Input type="number" placeholder="25" className="h-14 bg-white/5 border-white/10 text-white rounded-2xl" value={formData.age} onChange={(e) => setFormData({...formData, age: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label className="text-white/80">Gender</Label>
              <Select onValueChange={(v) => setFormData({...formData, gender: v})}>
                <SelectTrigger className="h-14 bg-white/5 border-white/10 text-white rounded-2xl"><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent><SelectItem value="male">Male</SelectItem><SelectItem value="female">Female</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "The Metrics",
      desc: "Let's calibrate your physical profile.",
      icon: Zap,
      content: (
        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-white/80">Height (cm)</Label>
            <Input type="number" placeholder="175" className="h-14 bg-white/5 border-white/10 text-white rounded-2xl" value={formData.height} onChange={(e) => setFormData({...formData, height: e.target.value})} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white/80">Current Weight (kg)</Label>
              <Input type="number" placeholder="80" className="h-14 bg-white/5 border-white/10 text-white rounded-2xl" value={formData.weight} onChange={(e) => setFormData({...formData, weight: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label className="text-white/80">Target Weight (kg)</Label>
              <Input type="number" placeholder="72" className="h-14 bg-white/5 border-white/10 text-white rounded-2xl" value={formData.targetWeight} onChange={(e) => setFormData({...formData, targetWeight: e.target.value})} />
            </div>
          </div>
        </div>
      )
    },
    {
      title: "The Vision",
      desc: "What is your primary focus?",
      icon: Target,
      content: (
        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-white/80">Primary Fitness Goal</Label>
            <Select onValueChange={(v) => setFormData({...formData, goal: v})}>
              <SelectTrigger className="h-14 bg-white/5 border-white/10 text-white rounded-2xl"><SelectValue placeholder="Focus" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="weight loss">Weight Loss</SelectItem>
                <SelectItem value="muscle gain">Muscle Gain</SelectItem>
                <SelectItem value="endurance">Endurance</SelectItem>
                <SelectItem value="maintenance">Maintenance</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-white/80">Activity Level</Label>
            <Select onValueChange={(v) => setFormData({...formData, activityLevel: v})}>
              <SelectTrigger className="h-14 bg-white/5 border-white/10 text-white rounded-2xl"><SelectValue placeholder="Lifestyle" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="sedentary">Sedentary</SelectItem>
                <SelectItem value="lightly active">Lightly Active</SelectItem>
                <SelectItem value="moderately active">Moderately Active</SelectItem>
                <SelectItem value="very active">Very Active</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )
    },
    {
      title: "The Preferences",
      desc: "Architect your environment.",
      icon: Dumbbell,
      content: (
        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-white/80">Workout Preference</Label>
            <Select onValueChange={(v) => setFormData({...formData, workoutPreference: v})}>
              <SelectTrigger className="h-14 bg-white/5 border-white/10 text-white rounded-2xl"><SelectValue placeholder="Environment" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="home">Home (Bodyweight/Light)</SelectItem>
                <SelectItem value="gym">Gym (Weights/Machines)</SelectItem>
                <SelectItem value="both">Both</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-white/80">Diet Style</Label>
            <Select onValueChange={(v) => setFormData({...formData, dietPreference: v})}>
              <SelectTrigger className="h-14 bg-white/5 border-white/10 text-white rounded-2xl"><SelectValue placeholder="Nutrition Preference" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="vegetarian">Pure Vegetarian</SelectItem>
                <SelectItem value="non-vegetarian">Non-Vegetarian</SelectItem>
                <SelectItem value="vegan">Vegan</SelectItem>
                <SelectItem value="eggetarian">Eggetarian</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )
    },
    {
      title: "The Commitment",
      desc: "Daily protocol parameters.",
      icon: Clock,
      content: (
        <div className="space-y-6">
          <div className="space-y-2 text-center">
            <Label className="text-white/80 text-lg mb-4 block">Available Daily Training Time</Label>
            <div className="flex justify-center items-baseline gap-2">
              <span className="text-5xl font-headline font-bold text-primary">{formData.availableWorkoutTime}</span>
              <span className="text-muted-foreground font-bold">MIN</span>
            </div>
            <input 
              type="range" 
              min="15" 
              max="120" 
              step="5"
              value={formData.availableWorkoutTime}
              onChange={(e) => setFormData({...formData, availableWorkoutTime: e.target.value})}
              className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer accent-primary mt-8"
            />
            <div className="flex justify-between text-[10px] text-muted-foreground font-bold mt-2 px-1">
              <span>EXPRESS (15m)</span>
              <span>ELITE (120m)</span>
            </div>
          </div>
        </div>
      )
    }
  ]

  const ActiveStep = steps[step]

  return (
    <div className="min-h-screen bg-[#050706] relative overflow-hidden safe-p-bottom">
      <div className="absolute top-[-10%] right-[-10%] w-64 h-64 bg-primary/20 rounded-full blur-[100px]" />
      
      <div className="p-6 pt-12 flex flex-col h-full min-h-screen">
        <header className="mb-8 flex items-center justify-between">
          <div className="flex gap-1.5">
            {steps.map((_, i) => (
              <div 
                key={i} 
                className={cn(
                  "h-1.5 rounded-full transition-all duration-500",
                  step === i ? "w-8 bg-primary" : i < step ? "w-4 bg-primary/40" : "w-4 bg-white/10"
                )} 
              />
            ))}
          </div>
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Protocol Sync</span>
        </header>

        <div className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="space-y-3">
                <div className="w-16 h-16 rounded-2xl glass flex items-center justify-center mb-6 shadow-xl">
                  <ActiveStep.icon className="w-8 h-8 text-primary animate-float" />
                </div>
                <h1 className="text-3xl font-headline font-bold text-white tracking-tight">{ActiveStep.title}</h1>
                <p className="text-muted-foreground text-sm">{ActiveStep.desc}</p>
              </div>

              <GlassCard className="mt-8 border-white/5 bg-white/[0.02]">
                {ActiveStep.content}
              </GlassCard>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="mt-12 flex gap-4">
          {step > 0 && (
            <Button 
              variant="ghost" 
              onClick={prev} 
              className="h-16 w-16 rounded-2xl border border-white/10 text-white hover:bg-white/5"
            >
              <ChevronLeft className="w-6 h-6" />
            </Button>
          )}
          <Button 
            onClick={step === steps.length - 1 ? handleFinish : next} 
            disabled={loading}
            className="flex-1 h-16 rounded-2xl emerald-gradient text-lg font-bold text-black shadow-2xl group"
          >
            {loading ? (
              <span className="flex items-center gap-2">CALIBRATING...</span>
            ) : step === steps.length - 1 ? (
              <span className="flex items-center gap-2 uppercase tracking-widest text-sm">Initialize Hub <Sparkles className="w-4 h-4" /></span>
            ) : (
              <span className="flex items-center gap-2 uppercase tracking-widest text-sm">Continue <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" /></span>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
