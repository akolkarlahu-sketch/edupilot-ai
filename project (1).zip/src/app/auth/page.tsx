
"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider 
} from "firebase/auth"
import { useAuth } from "@/firebase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { GlassCard } from "@/components/GlassCard"
import { Sparkles, Mail, Lock, LogIn } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { motion } from "framer-motion"

export default function AuthPage() {
  const auth = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [isLogin, setIsLogin] = useState(true)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!auth) return
    setLoading(true)

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password)
      } else {
        await createUserWithEmailAndPassword(auth, email, password)
      }
      router.push("/onboarding")
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Auth Failed",
        description: error.message,
      })
    } finally {
      setLoading(false)
    }
  }

  const handleGoogleAuth = async () => {
    if (!auth) return
    const provider = new GoogleAuthProvider()
    try {
      await signInWithPopup(auth, provider)
      router.push("/onboarding")
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Google Login Failed",
        description: error.message,
      })
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#050706] relative overflow-hidden">
      <div className="absolute top-[-10%] right-[-10%] w-64 h-64 bg-primary/20 rounded-full blur-[100px]" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-8"
      >
        <div className="text-center space-y-4">
          <div className="w-20 h-20 rounded-[32px] emerald-gradient mx-auto flex items-center justify-center shadow-2xl">
            <Sparkles className="w-10 h-10 text-black" />
          </div>
          <h1 className="text-4xl font-headline font-bold text-white tracking-tighter">
            {isLogin ? "Welcome Back" : "Join the Elite"}
          </h1>
          <p className="text-muted-foreground">Log in to sync your fitness protocol.</p>
        </div>

        <GlassCard className="space-y-6">
          <form onSubmit={handleEmailAuth} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-white/70">Email Address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="pl-10 bg-white/5 border-white/10 text-white"
                  required
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-white/70">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pl-10 bg-white/5 border-white/10 text-white"
                  required
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 rounded-2xl emerald-gradient text-black font-bold disabled:opacity-50"
              disabled={loading}
            >
              {loading ? "Authenticating..." : isLogin ? "Sign In" : "Create Account"}
              <LogIn className="ml-2 w-4 h-4" />
            </Button>
          </form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-white/10" /></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-[#050706] px-2 text-muted-foreground">Or continue with</span></div>
          </div>

          <Button 
            variant="outline" 
            onClick={handleGoogleAuth}
            className="w-full h-12 rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/action/google.svg" className="w-5 h-5 mr-2" alt="Google" />
            Google Workspace
          </Button>
        </GlassCard>

        <button 
          onClick={() => setIsLogin(!isLogin)}
          className="w-full text-center text-sm text-primary font-bold hover:underline"
        >
          {isLogin ? "Need an account? Sign up" : "Already have an account? Sign in"}
        </button>
      </motion.div>
    </div>
  )
}
