
"use client"

import { useState, useMemo, useEffect } from "react"
import { GlassCard } from "@/components/GlassCard"
import { Navigation } from "@/components/Navigation"
import { CelebrationOverlay } from "@/components/CelebrationOverlay"
import { Badge } from "@/components/ui/badge"
import { Clock, Dumbbell, Zap, Sparkles, Loader2, CheckCircle2, Volume2 } from "lucide-react"
import { useStore } from "@/lib/store"
import { generateWorkoutPlan } from "@/ai/flows/workout-plan-generator"
import { getVoiceInstruction } from "@/ai/flows/voice-instruction-flow"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { useUser, useFirestore, useDoc, useCollection, useMemoFirebase } from "@/firebase"
import { doc, updateDoc, increment, collection, addDoc, query, orderBy, limit } from "firebase/firestore"
import { logEvent } from "@/firebase/analytics"
import { Skeleton } from "@/components/ui/skeleton"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

export default function WorkoutsPage() {
  const { user: authUser } = useUser()
  const db = useFirestore()
  const { triggerCelebration } = useStore()
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)
  const [isVoicing, setIsVoicing] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const userDocRef = useMemoFirebase(() => 
    authUser ? doc(db, 'users', authUser.uid) : null, 
  [db, authUser])
  const { data: profile, loading: profileLoading } = useDoc<any>(userDocRef as any)

  const workoutPlansQuery = useMemoFirebase(() => {
    if (!authUser) return null
    return query(collection(db, 'users', authUser.uid, 'workouts'), orderBy('createdAt', 'desc'), limit(1))
  }, [db, authUser])
  const { data: plans, loading: plansLoading } = useCollection<any>(workoutPlansQuery)
  const currentPlan = plans?.[0]

  const handleVoiceGuide = async (text: string) => {
    if (isVoicing) return
    setIsVoicing(true)
    try {
      const { audioData } = await getVoiceInstruction(text)
      const audio = new Audio(audioData)
      audio.onended = () => setIsVoicing(false)
      audio.play()
    } catch (err) {
      toast({ variant: "destructive", title: "Voice Link Error", description: "Audio buffer overflow." })
      setIsVoicing(false)
    }
  }

  const handleGeneratePlan = async () => {
    if (!profile || !authUser) return
    setIsGenerating(true)
    logEvent('workout_generation_initiated', { goal: profile.goal })
    try {
      const plan = await generateWorkoutPlan({
        name: profile.name,
        age: profile.age,
        gender: profile.gender,
        heightCm: profile.height,
        weightKg: profile.weight,
        fitnessGoal: profile.goal,
        activityLevel: profile.activityLevel,
        workoutPreference: profile.workoutPreference || "home"
      })
      const workoutCollection = collection(db, 'users', authUser.uid, 'workouts');
      const payload = {
        ...plan,
        userId: authUser.uid,
        createdAt: new Date().toISOString()
      };
      
      addDoc(workoutCollection, payload)
        .catch(async () => {
          errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: `users/${authUser.uid}/workouts`,
            operation: 'create',
            requestResourceData: payload
          }));
        });
        
      logEvent('workout_generation_success')
      toast({ title: "Neural Protocol Active", description: "Your custom training plan is ready." })
    } catch (error) {
      toast({ variant: "destructive", title: "Coach Error", description: "Recalibration failed." })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleCompleteWorkout = async (focus: string) => {
    if (!authUser || !profile) return
    triggerCelebration('workout')
    logEvent('workout_completed', { focus, streak: (profile.streak || 0) + 1 })
    const userRef = doc(db, 'users', authUser.uid)
    const updatePayload = {
      totalWorkouts: increment(1),
      streak: increment(1),
      points: increment(100),
      lastActivityDate: new Date().toISOString()
    };

    updateDoc(userRef, updatePayload)
      .catch(async () => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: userRef.path,
          operation: 'update',
          requestResourceData: updatePayload
        }));
      });

    toast({ title: "Protocol Logged", description: `Session synchronized. +100 Elite Points.` })
  }

  if (!isMounted || profileLoading || plansLoading) return <WorkoutSkeleton />

  return (
    <div className="min-h-screen pb-40 bg-[#050706] relative">
      <CelebrationOverlay />
      
      <header className="p-8 pt-16 space-y-8 sticky top-0 z-40 bg-[#050706]/60 backdrop-blur-xl border-b border-white/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl glass flex items-center justify-center border-primary/20 shadow-lg">
              <Dumbbell className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-3xl font-headline font-bold text-white tracking-tighter">Train <span className="text-primary">Hub</span></h1>
          </div>
        </div>
        
        <GlassCard variant="emerald" className="p-8 border-primary/20" hover>
          <div className="flex flex-col items-center text-center space-y-6">
            <div className="w-20 h-20 rounded-[40px] glass flex items-center justify-center relative">
              <Sparkles className="w-10 h-10 text-primary" />
              <div className="absolute -inset-2 rounded-[44px] border border-primary/20 animate-ping" />
            </div>
            <Button onClick={handleGeneratePlan} disabled={isGenerating} className="w-full h-16 rounded-[24px] emerald-gradient text-black font-bold uppercase tracking-widest text-xs btn-premium">
              {isGenerating ? <Loader2 className="w-6 h-6 animate-spin" /> : "Re-Architect Protocol"}
            </Button>
          </div>
        </GlassCard>
      </header>

      <div className="px-6 space-y-10 mt-6">
        <AnimatePresence mode="popLayout">
          {currentPlan ? (
            <div className="space-y-8">
              {currentPlan.planDetails.slice(0, 4).map((day: any, i: number) => (
                <motion.div key={day.day} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                  <GlassCard className="p-0 overflow-hidden bg-black/40 border-white/5" hover>
                    <div className="p-8">
                      <div className="flex justify-between items-start mb-8">
                        <div className="space-y-2">
                          <span className="text-[10px] font-bold text-primary uppercase tracking-[0.3em]">{day.day}</span>
                          <h3 className="text-3xl font-headline font-bold text-white tracking-tighter leading-none">{day.focus}</h3>
                        </div>
                        <Button variant="ghost" className="h-12 w-12 rounded-2xl glass border-white/5" onClick={() => handleVoiceGuide(`Starting your ${day.focus} session. First exercise is ${day.exercises[0].name}`)}>
                          {isVoicing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Volume2 className="w-5 h-5 text-primary" />}
                        </Button>
                      </div>

                      <div className="space-y-5 mb-10">
                        {day.exercises.slice(0, 3).map((ex: any, j: number) => (
                          <div key={j} className="flex items-center justify-between">
                            <span className="text-[13px] text-white/80 font-bold">{ex.name}</span>
                            <Badge variant="outline" className="rounded-lg border-white/5 text-[10px]">{ex.sets} × {ex.reps}</Badge>
                          </div>
                        ))}
                      </div>

                      <Button onClick={() => handleCompleteWorkout(day.focus)} className="w-full h-16 rounded-[24px] bg-white/5 hover:bg-primary hover:text-black font-bold uppercase tracking-widest text-[10px] border border-white/10 btn-premium">
                        Complete Protocol <CheckCircle2 className="ml-2 w-4 h-4" />
                      </Button>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 space-y-4">
              <Dumbbell className="w-16 h-16 text-white/10 mx-auto" />
              <p className="text-muted-foreground text-sm">No training protocol found. Use AI Architect above.</p>
            </div>
          )}
        </AnimatePresence>
      </div>
      <Navigation />
    </div>
  )
}

function WorkoutSkeleton() {
  return (
    <div className="min-h-screen p-8 pt-20 space-y-10 bg-[#050706]">
      <div className="flex items-center gap-4">
        <Skeleton className="w-12 h-12 rounded-2xl bg-white/5" />
        <Skeleton className="h-10 w-48 bg-white/5 rounded-2xl" />
      </div>
      <Skeleton className="h-64 rounded-[40px] bg-white/5" />
      <div className="space-y-8">
        <Skeleton className="h-64 rounded-[32px] bg-white/5" />
        <Skeleton className="h-64 rounded-[32px] bg-white/5" />
      </div>
    </div>
  )
}
