
"use client"

import { useState, useEffect, useMemo } from "react"
import { GlassCard } from "@/components/GlassCard"
import { Navigation } from "@/components/Navigation"
import { Progress } from "@/components/ui/progress"
import { 
  Utensils, 
  Coffee, 
  Sun, 
  Moon, 
  Sparkles,
  Loader2,
  ChevronRight,
  TrendingDown,
  Scale
} from "lucide-react"
import { generateIndianDietPlan } from "@/ai/flows/indian-diet-plan-generator"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import { useUser, useFirestore, useDoc, useCollection, useMemoFirebase } from "@/firebase"
import { doc, collection, query, orderBy, limit, addDoc } from "firebase/firestore"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"
import { logEvent } from "@/firebase/analytics"

export default function DietPage() {
  const { user: authUser } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const userDocRef = useMemoFirebase(() => 
    authUser ? doc(db, 'users', authUser.uid) : null, 
  [db, authUser])
  const { data: profile, loading: profileLoading } = useDoc<any>(userDocRef as any)

  const dietPlansQuery = useMemoFirebase(() => {
    if (!authUser) return null
    return query(collection(db, 'users', authUser.uid, 'diet_plans'), orderBy('createdAt', 'desc'), limit(1))
  }, [db, authUser])
  const { data: plans, loading: plansLoading } = useCollection<any>(dietPlansQuery)
  const currentDietPlan = plans?.[0]

  const totalCalGoal = useMemo(() => {
    return currentDietPlan?.dietPlan[0]?.dailyTotals.totalCalories || 2400
  }, [currentDietPlan])

  const handleGeneratePlan = async () => {
    if (!profile || !authUser) return
    setIsGenerating(true)
    logEvent('diet_generation_initiated')
    try {
      const plan = await generateIndianDietPlan({
        age: profile.age,
        weightKg: profile.weight,
        heightCm: profile.height,
        gender: profile.gender as any,
        fitnessGoal: profile.goal,
        dietPreference: profile.dietPreference,
        activityLevel: profile.activityLevel as any,
        targetCalories: 2200,
        targetProteinGrams: 160,
        targetCarbsGrams: 220,
        targetFatsGrams: 65
      })

      const dietRef = collection(db, 'users', authUser.uid, 'diet_plans')
      addDoc(dietRef, {
        ...plan,
        userId: authUser.uid,
        createdAt: new Date().toISOString()
      }).catch(async (e) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: `users/${authUser.uid}/diet_plans`,
          operation: 'create',
          requestResourceData: plan
        }))
      })

      logEvent('diet_generation_success')
      toast({ title: "Nutrition Architecture Complete", description: "7-day elite Indian diet plan active." })
    } catch (error) {
      toast({ variant: "destructive", title: "Sync Failed", description: "Could not architect meal plan." })
    } finally {
      setIsGenerating(false)
    }
  }

  if (!isMounted || profileLoading || plansLoading) return <DietSkeleton />

  const currentDayPlan = currentDietPlan?.dietPlan[0]

  return (
    <div className="min-h-screen pb-40 bg-[#050706]">
      <header className="p-8 pt-16 space-y-10 sticky top-0 z-40 bg-[#050706]/60 backdrop-blur-xl">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center justify-between"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl glass flex items-center justify-center border-primary/20">
              <Utensils className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-3xl font-headline font-bold text-white tracking-tighter">Fuel <span className="text-primary">Hub</span></h1>
          </div>
          <Scale className="w-5 h-5 text-white/20" />
        </motion.div>
        
        <GlassCard variant="emerald" className="p-8 overflow-hidden relative" hover>
          <div className="absolute -top-12 -right-12 opacity-5 blur-2xl">
            <Utensils className="w-56 h-56 text-white" />
          </div>
          <div className="flex justify-between items-end mb-10 relative z-10">
            <div>
              <p className="text-[10px] font-bold text-primary uppercase tracking-[0.3em] mb-2">Neural Calorie Sync</p>
              <h2 className="text-5xl font-headline font-bold text-white tracking-tighter">
                {totalCalGoal} <span className="text-xs font-bold text-muted-foreground ml-1 uppercase tracking-widest">target</span>
              </h2>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] mb-2">Maintenance</p>
              <p className="text-lg font-headline font-bold text-white tracking-tight">Active <span className="text-[10px] font-bold">Protocol</span></p>
            </div>
          </div>
          <Progress value={65} className="h-2 bg-white/5" />
          
          <div className="grid grid-cols-3 gap-6 mt-10 relative z-10">
            <MacroStats label="Protein" value="160g" color="bg-primary" />
            <MacroStats label="Carbs" value="220g" color="bg-accent" />
            <MacroStats label="Fats" value="65g" color="bg-orange-500" />
          </div>
        </GlassCard>
      </header>

      <div className="px-6 space-y-10 mt-6">
        {!currentDietPlan ? (
          <div className="py-20 text-center space-y-10">
            <div className="relative inline-block">
              <div className="w-28 h-28 rounded-[44px] glass mx-auto flex items-center justify-center relative z-10 shadow-2xl">
                <Sparkles className="w-12 h-12 text-primary animate-pulse" />
              </div>
              <div className="absolute -inset-4 rounded-[48px] border border-primary/20 animate-ping [animation-duration:4s]" />
            </div>
            <div className="space-y-3">
              <h3 className="text-2xl font-headline font-bold text-white tracking-tight">Fuel Your Potential</h3>
              <p className="text-sm text-muted-foreground max-w-[260px] mx-auto leading-relaxed">Let FitSutra AI architect a precise Indian meal protocol for your biomechanics.</p>
            </div>
            <Button 
              onClick={handleGeneratePlan}
              disabled={isGenerating}
              className="h-20 px-12 rounded-[32px] emerald-gradient text-black font-bold text-lg shadow-2xl btn-premium"
            >
              {isGenerating ? <Loader2 className="w-7 h-7 animate-spin" /> : "Architect AI Fuel Plan"}
            </Button>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-bold text-white uppercase tracking-[0.3em]">Daily Protocol</h3>
              <button 
                onClick={handleGeneratePlan}
                className="flex items-center gap-2 text-primary text-[10px] font-bold uppercase tracking-[0.2em] hover:opacity-80"
              >
                <Sparkles className="w-3.5 h-3.5" /> Re-sync
              </button>
            </div>

            <div className="space-y-6">
              <AnimatePresence mode="popLayout">
                {currentDayPlan?.meals.map((meal: any, i: number) => (
                  <motion.div
                    key={`${meal.dishName}-${i}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <GlassCard className="flex items-center justify-between py-6 group bg-black/40 border-white/5" hover>
                      <div className="flex items-center gap-6">
                        <div className="w-14 h-14 rounded-[24px] glass-dark flex items-center justify-center shadow-inner group-hover:border-primary/40 transition-all duration-500">
                          {i === 0 ? <Coffee className="w-6 h-6 text-yellow-400" /> : 
                           i === 1 ? <Sun className="w-6 h-6 text-orange-400" /> : 
                           <Moon className="w-6 h-6 text-blue-400" />}
                        </div>
                        <div className="space-y-1.5">
                          <p className="text-[10px] font-bold text-primary uppercase tracking-[0.3em]">{meal.mealType}</p>
                          <h4 className="font-bold text-white text-[15px] tracking-tight line-clamp-1">{meal.dishName}</h4>
                          <div className="flex items-center gap-3 text-[10px] text-muted-foreground font-bold uppercase tracking-widest">
                            <span className="text-white/60">{meal.protein}g P</span>
                            <div className="w-1 h-1 rounded-full bg-white/10" />
                            <span>{meal.calories} kcal</span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-white transition-all" />
                    </GlassCard>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <GlassCard className="bg-blue-500/5 border-blue-500/10 py-7 px-8" hover>
              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 rounded-2xl glass flex items-center justify-center shrink-0 border-blue-500/20 shadow-lg">
                  <TrendingDown className="w-6 h-6 text-blue-400" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-[10px] font-bold text-blue-400 uppercase tracking-[0.3em]">Protocol Adjustment</h4>
                  <p className="text-[12px] text-muted-foreground leading-relaxed">
                    Substituting white rice with <strong className="text-white">Steel Cut Oats</strong> or <strong className="text-white">Millet</strong> today will optimize glycemic response and hit fiber goals.
                  </p>
                </div>
              </div>
            </GlassCard>
          </>
        )}
      </div>

      <Navigation />
    </div>
  )
}

function MacroStats({ label, value, color }: { label: string, value: string, color: string }) {
  return (
    <div className="text-center space-y-3">
      <p className="text-[10px] text-white/20 uppercase font-bold tracking-[0.2em]">{label}</p>
      <p className="text-sm font-headline font-bold text-white tracking-tight">{value}</p>
      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: "85%" }}
          className={`h-full ${color}`} 
        />
      </div>
    </div>
  )
}

function DietSkeleton() {
  return (
    <div className="min-h-screen p-8 pt-20 space-y-10 bg-[#050706]">
      <div className="flex items-center gap-4">
        <Skeleton className="w-12 h-12 rounded-2xl bg-white/5" />
        <Skeleton className="h-10 w-48 bg-white/5 rounded-2xl" />
      </div>
      <Skeleton className="h-64 rounded-[40px] bg-white/5" />
      <div className="space-y-6">
        <Skeleton className="h-4 w-24 bg-white/5" />
        <Skeleton className="h-24 rounded-[32px] bg-white/5" />
        <Skeleton className="h-24 rounded-[32px] bg-white/5" />
      </div>
    </div>
  )
}
