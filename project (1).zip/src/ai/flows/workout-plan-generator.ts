'use server';
/**
 * @fileOverview A Genkit flow for generating personalized workout plans.
 *
 * - generateWorkoutPlan - A function that handles the workout plan generation process.
 * - WorkoutPlanGeneratorInput - The input type for the generateWorkoutPlan function.
 * - WorkoutPlanGeneratorOutput - The return type for the generateWorkoutPlan function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const WorkoutPlanGeneratorInputSchema = z.object({
  name: z.string().describe('The name of the user.'),
  age: z.number().int().positive().describe('The age of the user in years.'),
  gender: z.string().describe('The gender of the user.'),
  heightCm: z.number().positive().describe('The height of the user in centimeters.'),
  weightKg: z.number().positive().describe('The weight of the user in kilograms.'),
  fitnessGoal: z.string().describe('The primary fitness goal (e.g., "muscle gain", "fat loss", "endurance", "overall fitness", "strength training").'),
  activityLevel: z.string().describe('The current activity level (e.g., "sedentary", "lightly active", "moderately active", "very active", "extremely active").'),
  workoutPreference: z.string().describe('The preferred workout environment ("home", "gym", "both").'),
  medicalConditions: z.string().optional().describe('Any existing medical conditions or injuries the user has. Important for safety considerations.'),
  dietaryRestrictions: z.string().optional().describe('Any dietary restrictions or preferences the user has. Not directly used for workout plan but good for holistic advice.'),
});
export type WorkoutPlanGeneratorInput = z.infer<typeof WorkoutPlanGeneratorInputSchema>;

const WorkoutPlanGeneratorOutputSchema = z.object({
  planName: z.string().describe('A descriptive name for the workout plan.'),
  durationWeeks: z.number().int().positive().describe('The suggested duration of the plan in weeks.'),
  goal: z.string().describe('The main goal this workout plan aims to achieve.'),
  planDetails: z.array(z.object({
    week: z.number().int().positive().describe('The week number for this part of the plan.'),
    day: z.string().describe('The specific day or phase (e.g., "Monday", "Rest Day", "Full Body Workout").'),
    focus: z.string().describe('The main focus of the workout for this day (e.g., "Upper Body", "Legs & Core", "Cardio").'),
    exercises: z.array(z.object({
      name: z.string().describe('The name of the exercise.'),
      sets: z.number().int().positive().describe('The number of sets for the exercise.'),
      reps: z.string().describe('The number of repetitions or duration (e.g., "8-12 reps", "30-60 seconds", "AMRAP").'),
      equipment: z.string().describe('Required equipment for the exercise (e.g., "Dumbbells", "Bodyweight", "Barbell", "Treadmill").'),
      instructions: z.string().optional().describe('Brief instructions or tips for the exercise.'),
    })).describe('A list of exercises for the day.'),
    notes: z.string().optional().describe('Any specific notes or warm-up/cool-down suggestions for the day.'),
  })).describe('A detailed breakdown of the workout plan, day by day, week by week.'),
  generalAdvice: z.string().describe('General advice regarding the workout plan, nutrition, rest, and safety.'),
  disclaimer: z.string().describe('A disclaimer stating that this plan is AI-generated and not a substitute for professional medical or fitness advice.'),
});
export type WorkoutPlanGeneratorOutput = z.infer<typeof WorkoutPlanGeneratorOutputSchema>;

export async function generateWorkoutPlan(input: WorkoutPlanGeneratorInput): Promise<WorkoutPlanGeneratorOutput> {
  return workoutPlanGeneratorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'workoutPlanGeneratorPrompt',
  input: {schema: WorkoutPlanGeneratorInputSchema},
  output: {schema: WorkoutPlanGeneratorOutputSchema},
  prompt: `You are an expert AI fitness coach named FitSutra AI. Your task is to create a personalized workout plan based on the user's provided information.

User Profile:
- Name: {{{name}}}
- Age: {{{age}}} years
- Gender: {{{gender}}}
- Height: {{{heightCm}}} cm
- Weight: {{{weightKg}}} kg
- Fitness Goal: {{{fitnessGoal}}}
- Activity Level: {{{activityLevel}}}
- Workout Preference: {{{workoutPreference}}}
{{#if medicalConditions}}- Medical Conditions: {{{medicalConditions}}}{{/if}}
{{#if dietaryRestrictions}}- Dietary Restrictions: {{{dietaryRestrictions}}}{{/if}}

Based on this information, generate a detailed 4 to 8-week workout plan. The plan should be structured week by week and day by day, including specific exercises, sets, reps, and required equipment, suitable for their preferred workout environment (home or gym).

Consider the user's fitness goal and activity level to create a progressive and effective routine. If the user has medical conditions, prioritize safety and suggest consulting a professional.

Make sure to include a "General Advice" section covering aspects like proper form, nutrition, rest, and listening to their body. Also, add a clear "Disclaimer".

Focus on creating a plan that is realistic, sustainable, and motivating.
`,
});

const workoutPlanGeneratorFlow = ai.defineFlow(
  {
    name: 'workoutPlanGeneratorFlow',
    inputSchema: WorkoutPlanGeneratorInputSchema,
    outputSchema: WorkoutPlanGeneratorOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    if (!output) {
      throw new Error('Failed to generate workout plan.');
    }
    return output;
  }
);
