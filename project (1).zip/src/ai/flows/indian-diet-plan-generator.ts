'use server';
/**
 * @fileOverview An AI agent for generating personalized Indian diet plans.
 *
 * - generateIndianDietPlan - A function that handles the Indian diet plan generation process.
 * - IndianDietPlanGeneratorInput - The input type for the generateIndianDietPlan function.
 * - IndianDietPlanGeneratorOutput - The return type for the generateIndianDietPlan function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const IndianDietPlanGeneratorInputSchema = z.object({
  age: z.number().int().positive().describe('The user\'s age in years.'),
  weightKg: z.number().positive().describe('The user\'s weight in kilograms.'),
  heightCm: z.number().positive().describe('The user\'s height in centimeters.'),
  gender: z.enum(['male', 'female', 'other']).describe('The user\'s gender.'),
  fitnessGoal: z.string().describe('The user\'s fitness goal (e.g., \'weight loss\', \'muscle gain\', \'maintenance\').'),
  dietPreference: z.string().describe('The user\'s diet preference (e.g., \'vegetarian\', \'non-vegetarian\', \'vegan\', \'lacto-vegetarian\').'),
  activityLevel: z.enum(['sedentary', 'lightly active', 'moderately active', 'very active', 'super active']).describe('The user\'s activity level.'),
  targetCalories: z.number().int().positive().describe('The target daily calorie intake.'),
  targetProteinGrams: z.number().int().positive().describe('The target daily protein intake in grams.'),
  targetCarbsGrams: z.number().int().positive().describe('The target daily carbohydrate intake in grams.'),
  targetFatsGrams: z.number().int().positive().describe('The target daily fat intake in grams.'),
});
export type IndianDietPlanGeneratorInput = z.infer<typeof IndianDietPlanGeneratorInputSchema>;

const IndianDietPlanGeneratorOutputSchema = z.object({
  dietPlan: z.array(z.object({
    day: z.string().describe('The day number or name (e.g., \'Day 1\', \'Monday\').'),
    meals: z.array(z.object({
      mealType: z.string().describe('The type of meal (e.g., \'Breakfast\', \'Lunch\', \'Dinner\', \'Snack 1\').'),
      dishName: z.string().describe('The name of the Indian dish.'),
      description: z.string().describe('A brief description of the dish, including key ingredients or preparation notes.'),
      calories: z.number().int().positive().describe('Calories for this meal.'),
      protein: z.number().positive().describe('Protein in grams for this meal.'),
      carbs: z.number().positive().describe('Carbohydrates in grams for this meal.'),
      fats: z.number().positive().describe('Fats in grams for this meal.'),
    })).describe('List of meals for the day.'),
    dailyTotals: z.object({
      totalCalories: z.number().int().positive().describe('Total calories for the day.'),
      totalProtein: z.number().positive().describe('Total protein in grams for the day.'),
      totalCarbs: z.number().positive().describe('Total carbohydrates in grams for the day.'),
      totalFats: z.number().positive().describe('Total fats in grams for the day.'),
    }).describe('Summary of daily macro totals.'),
  })).describe('A list of daily diet plans, typically for one week.'),
});
export type IndianDietPlanGeneratorOutput = z.infer<typeof IndianDietPlanGeneratorOutputSchema>;

export async function generateIndianDietPlan(input: IndianDietPlanGeneratorInput): Promise<IndianDietPlanGeneratorOutput> {
  return indianDietPlanGeneratorFlow(input);
}

const indianDietPlanGeneratorPrompt = ai.definePrompt({
  name: 'indianDietPlanGeneratorPrompt',
  input: { schema: IndianDietPlanGeneratorInputSchema },
  output: { schema: IndianDietPlanGeneratorOutputSchema },
  prompt: `You are an expert Indian nutritionist and diet planner. Your goal is to create a personalized, healthy, and culturally appropriate Indian diet plan for the user.

Generate a detailed 7-day Indian diet plan based on the following user profile and nutritional targets:

User Profile:
- Age: {{{age}}} years
- Weight: {{{weightKg}}} kg
- Height: {{{heightCm}}} cm
- Gender: {{{gender}}}
- Fitness Goal: {{{fitnessGoal}}}
- Diet Preference: {{{dietPreference}}}
- Activity Level: {{{activityLevel}}}

Nutritional Targets (Daily):
- Calories: {{{targetCalories}}} kcal
- Protein: {{{targetProteinGrams}}} grams
- Carbohydrates: {{{targetCarbsGrams}}} grams
- Fats: {{{targetFatsGrams}}} grams

Ensure the diet plan:
- Strictly adheres to Indian cuisine and dishes, providing specific dish names and brief descriptions.
- Distributes meals appropriately across Breakfast, Lunch, Dinner, and 1-2 Snacks.
- Attempts to closely match the daily nutritional targets for calories, protein, carbs, and fats.
- Provides a 'dailyTotals' summary for each day.
- Is healthy, balanced, and suitable for the user's fitness goal and diet preference.

Return the diet plan as a JSON object, strictly following the provided output schema.`,
});

const indianDietPlanGeneratorFlow = ai.defineFlow(
  {
    name: 'indianDietPlanGeneratorFlow',
    inputSchema: IndianDietPlanGeneratorInputSchema,
    outputSchema: IndianDietPlanGeneratorOutputSchema,
  },
  async (input) => {
    const { output } = await indianDietPlanGeneratorPrompt(input);
    if (!output) {
      throw new Error('Failed to generate Indian diet plan.');
    }
    return output;
  }
);
