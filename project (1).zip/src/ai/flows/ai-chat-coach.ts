'use server';
/**
 * @fileOverview This file implements the Genkit flow for the AI Chat Coach feature.
 * It allows users to chat with an AI coach to receive personalized fitness advice,
 * diet guidance (including Indian diet recommendations), and motivation.
 *
 * - aiChatCoach - A function that handles the AI chat coach interaction.
 * - AIChatCoachInput - The input type for the aiChatCoach function.
 * - AIChatCoachOutput - The return type for the aiChatCoach function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIChatCoachInputSchema = z.object({
  message: z.string().describe('The user\'s current message to the AI coach.'),
  userProfile: z.object({
    name: z.string(),
    age: z.number(),
    gender: z.string(),
    height: z.number(),
    weight: z.number(),
    goal: z.string(),
    activityLevel: z.string(),
    dietPreference: z.string(),
  }).optional().describe('The user\'s fitness profile for personalization.'),
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    content: z.string(),
  })).optional().describe('The previous conversation history between the user and the AI coach.'),
});
export type AIChatCoachInput = z.infer<typeof AIChatCoachInputSchema>;

const AIChatCoachOutputSchema = z.object({
  response: z.string().describe('The AI coach\'s conversational response providing fitness advice, diet guidance, or motivation.'),
});
export type AIChatCoachOutput = z.infer<typeof AIChatCoachOutputSchema>;

const aiChatCoachPrompt = ai.definePrompt({
  name: 'aiChatCoachPrompt',
  input: {schema: AIChatCoachInputSchema},
  output: {schema: AIChatCoachOutputSchema},
  prompt: `You are FitSutra AI, an elite, world-class Performance Coach. Your persona is professional, encouraging, and highly practical. 

User Context:
{{#if userProfile}}
- Name: {{{userProfile.name}}}
- Goal: {{{userProfile.goal}}}
- Metrics: {{{userProfile.weight}}}kg, {{{userProfile.height}}}cm
- Diet: {{{userProfile.dietPreference}}}
- Activity: {{{userProfile.activityLevel}}}
{{else}}
- New user, no profile data yet.
{{/if}}

Core Directive:
1. Provide short, actionable, and science-backed fitness advice. Be extremely concise.
2. Suggest Indian diet alternatives (e.g., Paneer/Soya instead of Tofu, or local millets).
3. Focus on home workouts if the user preference or context suggests it.
4. If asked about diet, always estimate a safe daily calorie range based on their goal (e.g., Weight Loss/Muscle Gain).
5. Use high-performance terminology but keep it accessible.
6. Personalize every response using the user's name if available.
7. Always maintain the "Elite Coach" persona—firm but motivating.

Conversation History:
{{#if history}}
  {{#each history}}
    {{#ifEquals role "user"}}User: {{content}}
    {{else}}FitSutra AI: {{content}}
    {{/ifEquals}}
  {{/each}}
{{/if}}

User: {{{message}}}

FitSutra AI:`,
});

const aiChatCoachFlow = ai.defineFlow(
  {
    name: 'aiChatCoachFlow',
    inputSchema: AIChatCoachInputSchema,
    outputSchema: AIChatCoachOutputSchema,
  },
  async (input) => {
    const {output} = await aiChatCoachPrompt(input);
    return output!;
  }
);

export async function aiChatCoach(input: AIChatCoachInput): Promise<AIChatCoachOutput> {
  return aiChatCoachFlow(input);
}
