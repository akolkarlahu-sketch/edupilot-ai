
'use server';
/**
 * @fileOverview AI Body Transformation Preview.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const TransformationInputSchema = z.object({
  photoDataUri: z.string().describe('Current photo of the user.'),
  goal: z.string().describe('User target goal (e.g., muscle gain, weight loss).'),
});
export type TransformationInput = z.infer<typeof TransformationInputSchema>;

export async function previewTransformation(input: TransformationInput): Promise<{ mediaUrl: string }> {
  const { media } = await ai.generate({
    model: 'googleai/gemini-2.5-flash-image',
    prompt: [
      { media: { url: input.photoDataUri } },
      { text: `Generate a photorealistic preview of this person having achieved their goal: ${input.goal}. Maintain facial features and background while enhancing muscle definition or lean physique as appropriate. Provide high resolution output.` }
    ],
    config: {
      responseModalities: ['TEXT', 'IMAGE'],
    },
  });

  if (!media) throw new Error('Visual synthesis failed.');
  return { mediaUrl: media.url };
}
