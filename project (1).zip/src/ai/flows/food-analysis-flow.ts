
'use server';
/**
 * @fileOverview AI Food Calorie and Macro Scanner.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const FoodAnalysisInputSchema = z.object({
  photoDataUri: z.string().describe('A photo of food as a data URI.'),
});
export type FoodAnalysisInput = z.infer<typeof FoodAnalysisInputSchema>;

const FoodAnalysisOutputSchema = z.object({
  dishName: z.string(),
  calories: z.number(),
  protein: z.number(),
  carbs: z.number(),
  fats: z.number(),
  confidence: z.number(),
  description: z.string(),
});
export type FoodAnalysisOutput = z.infer<typeof FoodAnalysisOutputSchema>;

export async function analyzeFood(input: FoodAnalysisInput): Promise<FoodAnalysisOutput> {
  const { output } = await ai.generate({
    model: 'googleai/gemini-2.5-flash',
    prompt: [
      { text: 'Analyze this food photo. Estimate its dish name, total calories, and macronutrients (protein, carbs, fats in grams). Be as accurate as possible for an Indian context if applicable.' },
      { media: { url: input.photoDataUri } }
    ],
    output: { schema: FoodAnalysisOutputSchema },
  });
  if (!output) throw new Error('Neural scan failed.');
  return output;
}
