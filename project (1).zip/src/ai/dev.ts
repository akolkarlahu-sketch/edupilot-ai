
import { config } from 'dotenv';
config();

import '@/ai/flows/indian-diet-plan-generator.ts';
import '@/ai/flows/workout-plan-generator.ts';
import '@/ai/flows/ai-chat-coach.ts';
import '@/ai/flows/food-analysis-flow.ts';
import '@/ai/flows/transformation-flow.ts';
import '@/ai/flows/voice-instruction-flow.ts';
